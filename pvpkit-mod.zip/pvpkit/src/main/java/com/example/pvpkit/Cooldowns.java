package com.example.pvpkit;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class Cooldowns {
    private static final Map<String, Long> MAP = new ConcurrentHashMap<>();

    private Cooldowns() {}

    /** Сколько миллисекунд осталось до конца кулдауна (0 = можно). */
    public static long remaining(UUID id, String key) {
        Long end = MAP.get(id + ":" + key);
        if (end == null) return 0;
        return Math.max(0, end - System.currentTimeMillis());
    }

    public static void set(UUID id, String key, long millis) {
        MAP.put(id + ":" + key, System.currentTimeMillis() + millis);
    }

    public static String format(long millis) {
        long s = (millis + 999) / 1000;
        if (s >= 3600) return (s / 3600) + " ч " + ((s % 3600) / 60) + " мин " + (s % 60) + " сек";
        if (s >= 60) return (s / 60) + " мин " + (s % 60) + " сек";
        return s + " сек";
    }
}
