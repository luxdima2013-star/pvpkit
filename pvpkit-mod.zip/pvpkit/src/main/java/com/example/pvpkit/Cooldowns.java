package com.example.pvpkit;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Кулдауны сохраняются в файл, поэтому не сбрасываются при перезапуске сервера. */
public final class Cooldowns {
    private static final Gson GSON = new Gson();
    private static final Type TYPE = new TypeToken<Map<String, Long>>() {}.getType();
    private static Map<String, Long> map = new HashMap<>();

    private Cooldowns() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvpkit-cooldowns.json");
    }

    public static synchronized void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Map<String, Long> loaded = GSON.fromJson(Files.readString(f), TYPE);
                if (loaded != null) map = new HashMap<>(loaded);
            }
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось загрузить кулдауны", e);
        }
    }

    private static void save() {
        try {
            long now = System.currentTimeMillis();
            map.values().removeIf(end -> end <= now); // чистим истёкшие
            Files.writeString(file(), GSON.toJson(map, TYPE));
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось сохранить кулдауны", e);
        }
    }

    /** Сколько миллисекунд осталось до конца кулдауна (0 = можно). */
    public static synchronized long remaining(UUID id, String key) {
        Long end = map.get(id + ":" + key);
        if (end == null) return 0;
        return Math.max(0, end - System.currentTimeMillis());
    }

    public static synchronized void set(UUID id, String key, long millis) {
        map.put(id + ":" + key, System.currentTimeMillis() + millis);
        save();
    }

    public static String format(long millis) {
        long s = (millis + 999) / 1000;
        if (s >= 3600) return (s / 3600) + " ч " + ((s % 3600) / 60) + " мин " + (s % 60) + " сек";
        if (s >= 60) return (s / 60) + " мин " + (s % 60) + " сек";
        return s + " сек";
    }
}
