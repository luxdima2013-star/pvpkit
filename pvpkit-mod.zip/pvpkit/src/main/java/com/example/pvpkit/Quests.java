package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.literal;

/** Ежедневные задания: у каждого игрока свои 3 задания на день, прогресс считается сам. */
public final class Quests {
    public enum Type { KILL_MOBS, MINE_ORES, HARVEST, PLAYTIME, BIOMES, KILL_PLAYERS, SELL_ITEMS }

    private record Template(Type type, String title, int target, long reward) {}

    public static final long ALL_DONE_BONUS = 3000;

    private static final List<Template> ALL = List.of(
            new Template(Type.KILL_MOBS, "Убить враждебных мобов", 25, 1500),
            new Template(Type.KILL_MOBS, "Убить враждебных мобов", 50, 3500),
            new Template(Type.MINE_ORES, "Добыть руды", 15, 1500),
            new Template(Type.MINE_ORES, "Добыть руды", 30, 3500),
            new Template(Type.HARVEST, "Собрать созревший урожай", 40, 1200),
            new Template(Type.HARVEST, "Собрать созревший урожай", 80, 2800),
            new Template(Type.PLAYTIME, "Провести на сервере (минут)", 30, 1000),
            new Template(Type.PLAYTIME, "Провести на сервере (минут)", 60, 2200),
            new Template(Type.BIOMES, "Открыть новых биомов", 2, 1500),
            new Template(Type.KILL_PLAYERS, "Убить игроков", 1, 2000),
            new Template(Type.SELL_ITEMS, "Продать предметов через /sell", 100, 1500));

    private Quests() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("quests").executes(ctx -> show(ctx.getSource().getPlayerOrThrow())));
    }

    private static String today() {
        return LocalDate.now().toString();
    }

    /** Три задания на сегодня: набор зависит от игрока и даты, хранить его не нужно. */
    private static List<Template> todays(UUID id, String day) {
        Random r = new Random(id.getMostSignificantBits() ^ id.getLeastSignificantBits() ^ day.hashCode());
        List<Type> types = new ArrayList<>(List.of(Type.values()));
        Collections.shuffle(types, r);
        List<Template> out = new ArrayList<>();
        for (Type t : types) {
            if (out.size() == 3) break;
            List<Template> options = new ArrayList<>();
            for (Template tpl : ALL) if (tpl.type() == t) options.add(tpl);
            out.add(options.get(r.nextInt(options.size())));
        }
        return out;
    }

    private static Progress.Data state(UUID id, String day) {
        Progress.Data d = Progress.get(id);
        if (!day.equals(d.questDay)) {
            d.questDay = day;
            d.qp = new int[3];
            d.qd = new boolean[3];
            d.qBonus = false;
        }
        return d;
    }

    /** Добавить прогресс по заданиям этого типа. */
    public static void add(ServerPlayerEntity p, Type type, int amount) {
        if (amount <= 0) return;
        String day = today();
        Progress.Data d = state(p.getUuid(), day);
        List<Template> qs = todays(p.getUuid(), day);
        boolean changed = false;

        for (int i = 0; i < 3; i++) {
            Template q = qs.get(i);
            if (q.type() != type || d.qd[i]) continue;
            d.qp[i] = Math.min(q.target(), d.qp[i] + amount);
            changed = true;
            if (d.qp[i] >= q.target()) {
                d.qd[i] = true;
                Economy.add(p.getUuid(), q.reward());
                p.sendMessage(Text.literal("Задание выполнено: " + q.title() + " (" + q.target() + ")! +" + q.reward()
                        + " коинов").formatted(Formatting.GREEN), false);
            }
        }

        if (d.qd[0] && d.qd[1] && d.qd[2] && !d.qBonus) {
            d.qBonus = true;
            Economy.add(p.getUuid(), ALL_DONE_BONUS);
            p.sendMessage(Text.literal("Все задания на сегодня выполнены! Бонус +" + ALL_DONE_BONUS + " коинов")
                    .formatted(Formatting.GOLD), false);
        }
        if (changed) Progress.saveLater();
    }

    private static int show(ServerPlayerEntity p) {
        String day = today();
        Progress.Data d = state(p.getUuid(), day);
        List<Template> qs = todays(p.getUuid(), day);
        p.sendMessage(Text.literal("=== Задания на сегодня ===").formatted(Formatting.AQUA), false);
        for (int i = 0; i < 3; i++) {
            Template q = qs.get(i);
            boolean done = d.qd[i];
            p.sendMessage(Text.literal((done ? "✓ " : "• ") + q.title() + ": " + d.qp[i] + "/" + q.target()
                    + " — награда " + q.reward()).formatted(done ? Formatting.GREEN : Formatting.YELLOW), false);
        }
        p.sendMessage(Text.literal("За все три задания — бонус " + ALL_DONE_BONUS + " коинов. Задания обновляются каждый день.")
                .formatted(Formatting.GRAY), false);
        return 1;
    }
}
