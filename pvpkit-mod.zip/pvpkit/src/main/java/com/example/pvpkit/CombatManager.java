package com.example.pvpkit;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public final class CombatManager {
    public static final int SECONDS = 30;
    private static final int DURATION = SECONDS * 20;
    /** Убивать игрока, если он вышел из игры во время PvP. */
    public static final boolean KILL_ON_LOGOUT = true;

    private static final Map<UUID, Integer> END = new HashMap<>();
    private static final Map<UUID, ServerBossBar> BARS = new HashMap<>();
    private static MinecraftServer server;

    private CombatManager() {}

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> server = s);
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {
            server = null;
            END.clear();
            BARS.clear();
        });

        // Удар / получение урона от игрока
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            Entity attacker = source.getAttacker();
            if (entity instanceof ServerPlayerEntity victim
                    && attacker instanceof ServerPlayerEntity hitter
                    && victim != hitter) {
                tag(victim);
                tag(hitter);
            }
            return true;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity p) untag(p.getUuid());
        });

        ServerTickEvents.END_SERVER_TICK.register(CombatManager::tick);

        ServerPlayConnectionEvents.DISCONNECT.register((handler, srv) -> {
            ServerPlayerEntity p = handler.player;
            if (isTagged(p)) {
                untag(p.getUuid());
                if (KILL_ON_LOGOUT) {
                    srv.getCommandManager().executeWithPrefix(srv.getCommandSource(), "kill " + p.getUuidAsString());
                }
            }
        });
    }

    public static boolean isTagged(ServerPlayerEntity p) {
        Integer end = END.get(p.getUuid());
        return end != null && server != null && end > server.getTicks();
    }

    private static void tag(ServerPlayerEntity p) {
        if (server == null) return;
        boolean fresh = !END.containsKey(p.getUuid());
        END.put(p.getUuid(), server.getTicks() + DURATION); // таймер обновляется при каждом ударе
        if (fresh) {
            ServerBossBar bar = new ServerBossBar(barText(SECONDS), BossBar.Color.RED, BossBar.Style.PROGRESS);
            bar.setPercent(1.0f);
            bar.addPlayer(p);
            BARS.put(p.getUuid(), bar);
            p.sendMessage(Text.literal("Вы вошли в режим PvP! Команды заблокированы на " + SECONDS + " сек.")
                    .formatted(Formatting.RED), false);
        }
    }

    private static void untag(UUID id) {
        END.remove(id);
        ServerBossBar bar = BARS.remove(id);
        if (bar != null) bar.clearPlayers();
    }

    private static Text barText(int sec) {
        return Text.literal("До окончания PvP режима: " + sec + " сек").formatted(Formatting.RED);
    }

    private static void tick(MinecraftServer srv) {
        if (END.isEmpty()) return;
        int now = srv.getTicks();
        Iterator<Map.Entry<UUID, Integer>> it = END.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Integer> e = it.next();
            UUID id = e.getKey();
            int left = e.getValue() - now;
            ServerPlayerEntity p = srv.getPlayerManager().getPlayer(id);
            ServerBossBar bar = BARS.get(id);
            if (p == null || left <= 0) {
                it.remove();
                if (bar != null) {
                    bar.clearPlayers();
                    BARS.remove(id);
                }
                if (p != null) {
                    p.sendMessage(Text.literal("PvP режим закончился. Команды снова доступны.")
                            .formatted(Formatting.GREEN), false);
                }
                continue;
            }
            if (bar != null && now % 4 == 0) {
                bar.setName(barText((left + 19) / 20));
                bar.setPercent(Math.min(1.0f, left / (float) DURATION));
            }
        }
    }
}
