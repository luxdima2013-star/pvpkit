package com.example.pvpkit;

import java.util.HashMap;
import java.util.Map;

/** Русские слова для поиска предметов: из английского id собирается строка с русскими формами слов. */
public final class RuNames {
    private static final String[] NOUN_END = {"", "а", "ы", "и", "у", "е", "ов", "ей", "ом", "ой"};
    private static final String[] ADJ_END = {"ый", "ая", "ое", "ые", "ой", "ого", "ых", "ым", "ий", "ее"};

    /** token=существительные(через запятую);прилагательные(основы через запятую) */
    private static final String DICT = """
            diamond=алмаз;алмазн
            netherite=незерит;незеритов
            iron=желез;железн
            golden=золот;золот
            gold=золот;золот
            copper=медь,мед;медн
            emerald=изумруд;изумрудн
            lapis=лазурит;лазурит
            redstone=редстоун,красная пыль;редстоун
            quartz=кварц;кварцев
            amethyst=аметист;аметист
            obsidian=обсидиан;обсидианов
            coal=уголь,угл;угольн
            charcoal=древесный уголь,угл;угольн
            stone=камен,камн;каменн
            cobblestone=булыжник;булыжн
            deepslate=глубинный сланец,сланец;глубинносланцев,сланцев
            dirt=земл;земляной
            grass=трав;травян
            sand=песок,песк;песчан
            red_sand=красный песок
            gravel=гравий;гравийн
            clay=глин;глиняный,глинян
            glass=стекл;стеклян
            wool=шерст;шерстян
            wood=дерев,древесин;деревян
            log=бревн
            planks=доск
            oak=дуб;дубов
            spruce=ель,ел;елов
            birch=берез;березов
            jungle=джунгл;джунглев
            acacia=акаци;акациев
            dark=темн;темн
            mangrove=мангр;мангров
            cherry=вишн;вишнев
            bamboo=бамбук;бамбуков
            crimson=багров;багров
            warped=искаженн;искаженн
            white=бел;бел
            orange=оранжев;оранжев
            magenta=пурпурн;пурпурн
            light=светл;светл
            blue=син,голуб;син,голуб
            yellow=желт;желт
            lime=лайм;лаймов
            pink=розов;розов
            gray=сер;сер
            cyan=бирюзов;бирюзов
            purple=фиолетов;фиолетов
            brown=коричнев;коричнев
            green=зелен;зелен
            red=красн;красн
            black=черн;черн
            sword=меч
            pickaxe=кирк
            axe=топор
            shovel=лопат
            hoe=мотыг
            helmet=шлем
            chestplate=нагрудник
            leggings=поножи
            boots=ботинок,ботинки,сапог
            bow=лук
            crossbow=арбалет
            arrow=стрел
            shield=щит
            trident=трезубец
            mace=булав
            elytra=элитр
            totem=тотем
            undying=бессмерт
            pearl=жемчуг
            ender=эндер,край;крайн
            eye=око
            apple=яблок
            carrot=морков
            potato=картофел,картошк
            beef=говядин
            steak=стейк
            cooked=жарен;жарен
            raw=сыр;сыр
            bread=хлеб
            cake=торт
            cookie=печень
            pie=пирог
            melon=арбуз,дын
            pumpkin=тыкв
            beetroot=свекл
            chicken=куриц,кур;курин
            porkchop=свинин
            mutton=баранин
            rabbit=кролик
            cod=треск
            salmon=лосос
            stew=рагу,суп
            bowl=миск
            bucket=ведр
            water=вод
            lava=лав
            milk=молок
            torch=факел
            lantern=фонар
            chest=сундук
            barrel=бочк
            furnace=печ
            table=стол
            crafting=верстак,крафт
            anvil=наковальн
            enchanting=зачарован
            enchanted=зачарован;зачарован
            brewing=зель
            stand=стойк
            bed=кроват
            door=двер
            trapdoor=люк
            fence=забор,огражд
            gate=калитк
            stairs=лестниц,ступен
            slab=плит,полублок
            wall=стен
            button=кнопк
            pressure=нажимн
            plate=пластин
            lever=рычаг
            sign=табличк
            ladder=лестниц
            rail=рельс
            minecart=вагонетк
            boat=лодк
            saddle=седл
            lead=поводок
            tag=бирк
            name=бирк
            book=книг
            paper=бумаг
            map=карт
            compass=компас
            clock=часы
            spyglass=подзорн
            fishing=удочк,рыболов
            rod=стержен,удочк
            flint=кремен
            bone=кост
            string=нит
            feather=пер
            leather=кож;кожан
            slime=слиз
            ball=шар
            honey=мед
            comb=сот
            bottle=бутыл,пузыр
            potion=зель
            experience=опыт
            dye=краситель
            banner=флаг,баннер
            pattern=узор
            skull=череп
            head=голов
            wither=иссушител
            dragon=драко,дракон
            egg=яйц
            nether=незер,нижн
            end=энд,край
            portal=портал
            star=звезд
            beacon=маяк
            conduit=морск
            sponge=губк
            prismarine=призмарин
            sea=морск
            shulker=шалкер
            box=ящик
            tnt=динамит
            crystal=кристалл
            gunpowder=порох
            fire=огн
            charge=заряд
            wind=ветр
            firework=фейерверк
            rocket=ракет
            block=блок
            ore=руд
            ingot=слитк
            nugget=самородок
            dust=пыль
            shard=осколок
            scrap=лом
            upgrade=улучшен
            template=шаблон
            smithing=кузнеч
            music=музык
            disc=пластинк
            wheat=пшениц
            seeds=сем
            sapling=саженц
            leaves=листв
            flower=цвет
            rose=роз
            tulip=тюльпан
            dandelion=одуванчик
            poppy=мак
            lily=лили,кувшинк
            vine=лоз
            moss=мох;мшист
            mushroom=гриб
            cactus=кактус
            sugar=сахар
            cane=тростник
            kelp=ламинари,водоросл
            coral=коралл
            fern=папоротник
            bush=куст
            azalea=азале
            glow=светящ;светящ
            berries=ягод
            sweet=сладк;сладк
            stripped=обтесан;обтесан
            polished=полирован;полирован
            cut=резн;резн
            smooth=гладк;гладк
            chiseled=резн;резн
            cracked=потрескавш;потрескавш
            mossy=мшист;мшист,замшел
            waxed=навощен;навощен
            exposed=окисл;окисл
            weathered=выветрен;выветрен
            oxidized=окислен;окислен
            tinted=тонирован;тонирован
            bricks=кирпич
            brick=кирпич
            tuff=туф
            basalt=базальт
            blackstone=чернокамен
            andesite=андезит
            diorite=диорит
            granite=гранит
            calcite=кальцит
            dripstone=капельник
            sandstone=песчаник
            terracotta=терракот
            concrete=бетон
            powder=порошок
            glazed=глазурован;глазурован
            mud=грязь,грязев
            snow=снег,снеж
            ice=лед,ледян
            packed=плотн;плотн
            magma=магм
            soul=душ
            glowstone=светокамень
            netherrack=незерак,адский камень
            cobweb=паутин
            hay=сено,сен
            bale=тюк
            carpet=ковер
            painting=картин
            frame=рамк
            item=предмет
            pot=горшок
            armor=брон
            horse=лошад
            bell=колокол
            campfire=костер
            jukebox=проигрыватель
            note=нот
            piston=поршень
            sticky=липк;липк
            observer=наблюдател
            dropper=выбрасыватель
            dispenser=раздатчик
            hopper=воронк
            comparator=компаратор
            repeater=повторител
            target=мишен
            tripwire=растяжк
            hook=крюк
            daylight=дневн
            detector=датчик
            sensor=датчик
            lightning=молни
            loom=ткацк
            grindstone=точил
            stonecutter=камнерез
            cartography=картограф
            fletching=лучн
            smoker=коптильн
            blast=доменн
            lectern=кафедр
            composter=компостер
            cauldron=котел
            scaffolding=леса
            respawn=возрожден
            anchor=якор
            lodestone=магнетит
            turtle=черепах
            scute=щиток
            phantom=фантом
            membrane=перепонк
            ghast=гаст
            tear=слез
            blaze=блейз
            rotten=гнил;гнил
            flesh=плоть
            spider=паук,паучь
            ink=чернил
            sac=мешочек
            heart=сердц
            nautilus=наутилус
            shell=ракушк
            trial=испытан
            key=ключ
            ominous=зловещ;зловещ
            bundle=узел
            """;

    private static final Map<String, String> MAP = new HashMap<>();

    static {
        for (String line : DICT.split("\n")) {
            int eq = line.indexOf('=');
            if (eq <= 0) continue;
            String token = line.substring(0, eq).trim();
            String body = line.substring(eq + 1).trim();
            StringBuilder sb = new StringBuilder();
            String[] parts = body.split(";", -1);
            for (String noun : parts[0].split(",")) {
                noun = noun.trim();
                if (noun.isEmpty()) continue;
                for (String end : NOUN_END) sb.append(noun).append(end).append(' ');
            }
            if (parts.length > 1) {
                for (String adj : parts[1].split(",")) {
                    adj = adj.trim();
                    if (adj.isEmpty()) continue;
                    sb.append(adj).append(' ');
                    for (String end : ADJ_END) sb.append(adj).append(end).append(' ');
                }
            }
            MAP.put(token, sb.toString());
        }
    }

    private RuNames() {}

    public static String normalize(String s) {
        return s.toLowerCase().replace('ё', 'е').replace('_', ' ');
    }

    /** Строка для поиска: английский id + русские формы слов. */
    public static String haystack(String path) {
        StringBuilder sb = new StringBuilder(normalize(path)).append(' ');
        for (String token : path.split("_")) {
            String ru = MAP.get(token);
            if (ru != null) sb.append(ru);
        }
        return normalize(sb.toString());
    }
}
