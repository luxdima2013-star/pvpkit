package com.example.pvpkit;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.Monster;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Коины: награда за убийство мобов, баланс хранится в файле. */
public final class Economy {
    private static final Gson GSON = new Gson();
    private static final Type TYPE = new TypeToken<Map<String, Long>>() {}.getType();
    private static Map<String, Long> balances = new HashMap<>();

    /** Награда за мобов. Все остальные враждебные мобы дают DEFAULT_REWARD. */
    public static final long DEFAULT_REWARD = 3;
    private static final Map<EntityType<?>, Long> REWARDS = new HashMap<>();

    static {
        REWARDS.put(EntityType.ZOMBIE, 5L);
        REWARDS.put(EntityType.SKELETON, 5L);
        REWARDS.put(EntityType.SPIDER, 4L);
        REWARDS.put(EntityType.CREEPER, 8L);
        REWARDS.put(EntityType.ENDERMAN, 15L);
        REWARDS.put(EntityType.WITCH, 15L);
        REWARDS.put(EntityType.BLAZE, 12L);
        REWARDS.put(EntityType.WITHER_SKELETON, 20L);
        REWARDS.put(EntityType.GHAST, 25L);
        REWARDS.put(EntityType.PIGLIN_BRUTE, 30L);
        REWARDS.put(EntityType.VINDICATOR, 20L);
        REWARDS.put(EntityType.EVOKER, 40L);
        REWARDS.put(EntityType.RAVAGER, 60L);
        REWARDS.put(EntityType.GUARDIAN, 15L);
        REWARDS.put(EntityType.ELDER_GUARDIAN, 150L);
        REWARDS.put(EntityType.SHULKER, 25L);
        REWARDS.put(EntityType.WARDEN, 500L);
        REWARDS.put(EntityType.WITHER, 1500L);
        REWARDS.put(EntityType.ENDER_DRAGON, 3000L);
    }

    private Economy() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvpkit-economy.json");
    }

    public static void init() {
        load();
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (!(source.getAttacker() instanceof ServerPlayerEntity killer)) return;
            if (!(entity instanceof Monster)) return;
            long reward = REWARDS.getOrDefault(entity.getType(), DEFAULT_REWARD);
            add(killer.getUuid(), reward);
            killer.sendMessage(Text.literal("+" + reward + " коинов (баланс: " + balance(killer.getUuid()) + ")")
                    .formatted(Formatting.GOLD), true);
        });
    }

    private static synchronized void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Map<String, Long> loaded = GSON.fromJson(Files.readString(f), TYPE);
                if (loaded != null) balances = new HashMap<>(loaded);
            }
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось загрузить балансы", e);
        }
    }

    private static void save() {
        try {
            Files.writeString(file(), GSON.toJson(balances, TYPE));
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось сохранить балансы", e);
        }
    }

    public static synchronized long balance(UUID id) {
        return balances.getOrDefault(id.toString(), 0L);
    }

    public static synchronized void add(UUID id, long amount) {
        balances.merge(id.toString(), amount, Long::sum);
        save();
    }

    /** true = списано, false = не хватает коинов. */
    public static synchronized boolean take(UUID id, long amount) {
        long have = balance(id);
        if (have < amount) return false;
        balances.put(id.toString(), have - amount);
        save();
        return true;
    }
}
