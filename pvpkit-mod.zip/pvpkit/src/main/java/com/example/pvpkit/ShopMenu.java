package com.example.pvpkit;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Меню-сундук «Рынок»: 45 товаров на странице + нижняя панель. Клик по товару = покупка. */
public class ShopMenu extends GenericContainerScreenHandler {
    private static final int PAGE_SIZE = 45;
    private static final int PREV = 45;
    private static final int INFO = 52;
    private static final int NEXT = 53;
    private static final int CAT_FIRST = 46; // 46..51 — вкладки

    private static final Item[] CATEGORY_ICONS = {
            Items.CHEST, Items.NETHER_STAR, Items.DIAMOND_SWORD, Items.COOKED_BEEF, Items.GRASS_BLOCK, Items.DRAGON_EGG
    };

    private final SimpleInventory inv;
    private final ServerPlayerEntity viewer;
    private final DynamicRegistryManager reg;
    private final String search;
    private int category = 0;
    private int page = 0;
    private List<Shop.Entry> list;

    private ShopMenu(int syncId, PlayerInventory playerInv, SimpleInventory inv,
                     ServerPlayerEntity viewer, DynamicRegistryManager reg, String search) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInv, inv, 6);
        this.inv = inv;
        this.viewer = viewer;
        this.reg = reg;
        this.search = search;
        rebuildList();
        refresh();
    }

    public static void open(ServerPlayerEntity player, DynamicRegistryManager reg, String search) {
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInv, p) -> new ShopMenu(syncId, playerInv, new SimpleInventory(54), player, reg, search),
                Text.literal(search == null ? "Рынок" : "Рынок: " + search)));
    }

    // ---------- клики ----------

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < 54
                && (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)) {
            handleClick(slotIndex, button);
        }
        setCursorStack(ItemStack.EMPTY);
        sendContentUpdates();
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    private void handleClick(int slot, int button) {
        if (slot < PAGE_SIZE) {
            int idx = page * PAGE_SIZE + slot;
            if (idx < list.size()) buy(list.get(idx), button == 1 ? 16 : 1);
        } else if (slot == PREV) {
            if (page > 0) { page--; refresh(); }
        } else if (slot == NEXT) {
            if (page < maxPage()) { page++; refresh(); }
        } else if (slot >= CAT_FIRST && slot < CAT_FIRST + 6) {
            category = slot - CAT_FIRST;
            page = 0;
            rebuildList();
            refresh();
        }
    }

    private void buy(Shop.Entry entry, int wanted) {
        int maxStack = new ItemStack(entry.item()).getMaxCount();
        int qty = Math.max(1, Math.min(wanted, maxStack));
        long total = entry.unitPrice() * qty;
        if (!Economy.take(viewer.getUuid(), total)) {
            viewer.sendMessage(Text.literal("Не хватает коинов: нужно " + total + ", у вас "
                    + Economy.balance(viewer.getUuid())).formatted(Formatting.RED), true);
            return;
        }
        viewer.getInventory().offerOrDrop(entry.create(reg, qty));
        viewer.sendMessage(Text.literal("Куплено x" + qty + " за " + total + " коинов. Баланс: "
                + Economy.balance(viewer.getUuid())).formatted(Formatting.GREEN), true);
        refresh(); // обновить баланс
    }

    // ---------- отрисовка ----------

    private int maxPage() {
        return Math.max(0, (list.size() - 1) / PAGE_SIZE);
    }

    private void rebuildList() {
        list = Shop.filter(category, search);
    }

    private static Text plain(String s, Formatting color) {
        return Text.literal(s).styled(st -> st.withItalic(false).withColor(color));
    }

    private static ItemStack named(Item item, String name, Formatting color, List<Text> lore) {
        ItemStack s = new ItemStack(item);
        s.set(DataComponentTypes.CUSTOM_NAME, plain(name, color));
        if (!lore.isEmpty()) s.set(DataComponentTypes.LORE, new LoreComponent(lore));
        return s;
    }

    private ItemStack display(Shop.Entry e) {
        ItemStack s = e.create(reg, 1);
        List<Text> lore = new ArrayList<>();
        lore.add(plain("Цена: " + e.unitPrice() + " коинов", Formatting.GOLD));
        lore.add(plain("ЛКМ — купить 1", Formatting.GRAY));
        int max = s.getMaxCount();
        if (max > 1) {
            int q = Math.min(16, max);
            lore.add(plain("ПКМ — купить " + q + " (" + (e.unitPrice() * q) + ")", Formatting.GRAY));
        }
        s.set(DataComponentTypes.LORE, new LoreComponent(lore));
        return s;
    }

    private void refresh() {
        if (page > maxPage()) page = maxPage();

        for (int i = 0; i < PAGE_SIZE; i++) {
            int idx = page * PAGE_SIZE + i;
            inv.setStack(i, idx < list.size() ? display(list.get(idx)) : ItemStack.EMPTY);
        }

        inv.setStack(PREV, page > 0
                ? named(Items.ARROW, "← Назад", Formatting.YELLOW, List.of())
                : ItemStack.EMPTY);
        inv.setStack(NEXT, page < maxPage()
                ? named(Items.ARROW, "Вперёд →", Formatting.YELLOW, List.of())
                : ItemStack.EMPTY);

        for (int c = 0; c < 6; c++) {
            boolean selected = c == category;
            ItemStack icon = named(CATEGORY_ICONS[c], Shop.CATEGORY_NAMES[c],
                    selected ? Formatting.GREEN : Formatting.WHITE,
                    List.of(plain(selected ? "Выбрано" : "Нажмите, чтобы открыть", Formatting.GRAY)));
            if (selected) icon.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
            inv.setStack(CAT_FIRST + c, icon);
        }

        inv.setStack(INFO, named(Items.GOLD_INGOT,
                "Баланс: " + Economy.balance(viewer.getUuid()) + " коинов", Formatting.GOLD,
                List.of(plain("Страница " + (page + 1) + " из " + (maxPage() + 1), Formatting.GRAY),
                        plain("Найдено товаров: " + list.size(), Formatting.GRAY))));
    }
}
