package com.example.pvpkit;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Map;

/**
 * Настоящие русские названия предметов. Файл ru_ru.json один раз скачивается с серверов Mojang
 * и кладётся в config/pvpkit-ru_ru.json. Если скачать не получилось — работает встроенный словарь.
 */
public final class RuLang {
    private static final String MC_VERSION = "1.21.11";
    private static volatile Map<String, String> lang = Map.of();

    private RuLang() {}

    public static void loadAsync() {
        Thread t = new Thread(RuLang::load, "pvpkit-lang");
        t.setDaemon(true);
        t.start();
    }

    /** Русское название предмета по его id (например "flint") или null. */
    public static String name(String path) {
        String n = lang.get("item.minecraft." + path);
        if (n == null) n = lang.get("block.minecraft." + path);
        return n;
    }

    private static void load() {
        try {
            Path cache = FabricLoader.getInstance().getConfigDir().resolve("pvpkit-ru_ru.json");
            String json;
            if (Files.exists(cache)) {
                json = Files.readString(cache, StandardCharsets.UTF_8);
            } else {
                json = download();
                Files.writeString(cache, json, StandardCharsets.UTF_8);
            }
            Map<String, String> parsed = new Gson().fromJson(json, new TypeToken<Map<String, String>>() {}.getType());
            if (parsed != null) lang = parsed;
            Shop.clearSearchCache();
            PvpKitMod.LOGGER.info("Русские названия загружены: {}", lang.size());
        } catch (Exception e) {
            PvpKitMod.LOGGER.warn("Не удалось загрузить ru_ru.json, поиск работает по встроенному словарю: {}", e.toString());
        }
    }

    private static String get(HttpClient client, String url) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(30)).GET().build();
        HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (resp.statusCode() != 200) throw new IllegalStateException("HTTP " + resp.statusCode() + " " + url);
        return resp.body();
    }

    private static String download() throws Exception {
        HttpClient client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(15))
                .followRedirects(HttpClient.Redirect.NORMAL)
                .build();

        JsonObject manifest = JsonParser.parseString(
                get(client, "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json")).getAsJsonObject();
        String versionUrl = null;
        JsonArray versions = manifest.getAsJsonArray("versions");
        for (JsonElement el : versions) {
            JsonObject v = el.getAsJsonObject();
            if (MC_VERSION.equals(v.get("id").getAsString())) {
                versionUrl = v.get("url").getAsString();
                break;
            }
        }
        if (versionUrl == null) throw new IllegalStateException("Версия " + MC_VERSION + " не найдена");

        JsonObject version = JsonParser.parseString(get(client, versionUrl)).getAsJsonObject();
        String indexUrl = version.getAsJsonObject("assetIndex").get("url").getAsString();

        JsonObject index = JsonParser.parseString(get(client, indexUrl)).getAsJsonObject();
        String hash = index.getAsJsonObject("objects").getAsJsonObject("minecraft/lang/ru_ru.json")
                .get("hash").getAsString();

        return get(client, "https://resources.download.minecraft.net/" + hash.substring(0, 2) + "/" + hash);
    }
}
