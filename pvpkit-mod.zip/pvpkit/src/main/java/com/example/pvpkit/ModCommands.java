package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.block.BlockState;
import net.minecraft.command.CommandSource;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.util.Set;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class ModCommands {
    private static final long SKILL_COOLDOWN = 15 * 60 * 1000L;
    private static final long KIT_COOLDOWN = 60 * 60 * 1000L;
    private static final long SPEED_COOLDOWN = 2 * 60 * 60 * 1000L;
    private static final long FEED_COOLDOWN = 15 * 60 * 1000L;
    private static final long SPAM_COOLDOWN = 3 * 1000L;

    private static final SuggestionProvider<ServerCommandSource> HOME_SUGGESTIONS = (ctx, builder) -> {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p != null) CommandSource.suggestMatching(HomeStorage.names(p.getUuid()), builder);
        return builder.buildFuture();
    };

    private ModCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("skill").executes(ModCommands::skill));
        d.register(literal("speed").executes(ModCommands::speed));
        d.register(literal("feed").executes(ModCommands::feed));

        d.register(literal("kit")
                .then(literal("start").executes(ModCommands::kitStart)));

        d.register(literal("sethome")
                .then(argument("name", StringArgumentType.word()).executes(ModCommands::setHome)));

        d.register(literal("home")
                .then(argument("name", StringArgumentType.word())
                        .suggests(HOME_SUGGESTIONS)
                        .executes(ModCommands::home)));

        d.register(literal("delhome")
                .then(argument("name", StringArgumentType.word())
                        .suggests(HOME_SUGGESTIONS)
                        .executes(ModCommands::delHome)));

        d.register(literal("homes").executes(ModCommands::homes));
    }

    // ---------- helpers ----------

    private static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    /** true = можно выполнять, кулдаун запущен. */
    private static boolean useCooldown(ServerPlayerEntity p, String key, long millis) {
        long left = Cooldowns.remaining(p.getUuid(), key);
        if (left > 0) {
            msg(p, "Подождите ещё " + Cooldowns.format(left), Formatting.RED);
            return false;
        }
        Cooldowns.set(p.getUuid(), key, millis);
        return true;
    }

    // ---------- /skill, /speed, /feed ----------

    private static int skill(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "skill", SKILL_COOLDOWN)) return 0;

        int ticks = 45 * 20;
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, ticks, 5)); // VI
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, ticks, 0));      // I
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, ticks, 1));   // II
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, ticks, 1));      // II

        msg(p, "Скилл активирован на 45 секунд!", Formatting.GREEN);
        return 1;
    }

    private static int speed(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "speed", SPEED_COOLDOWN)) return 0;

        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 20, 9)); // Скорость X, 20 сек
        msg(p, "Скорость X на 20 секунд!", Formatting.GREEN);
        return 1;
    }

    private static int feed(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "feed", FEED_COOLDOWN)) return 0;

        p.getHungerManager().setFoodLevel(20);
        msg(p, "Голод восполнен!", Formatting.GREEN);
        return 1;
    }

    // ---------- /kit start ----------

    private static void enchant(DynamicRegistryManager reg, ItemStack stack, RegistryKey<Enchantment> key, int level) {
        stack.addEnchantment(reg.getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(key), level);
    }

    private static void giveArmor(ServerPlayerEntity p, DynamicRegistryManager reg, EquipmentSlot slot, Item item) {
        ItemStack stack = new ItemStack(item);
        enchant(reg, stack, Enchantments.PROTECTION, 1);
        if (p.getEquippedStack(slot).isEmpty()) {
            p.equipStack(slot, stack);           // слот свободен — надеваем
        } else {
            p.getInventory().offerOrDrop(stack); // уже есть броня — кладём в инвентарь
        }
    }

    private static void give(ServerPlayerEntity p, Item item, int count) {
        p.getInventory().offerOrDrop(new ItemStack(item, count));
    }

    private static int kitStart(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "kit", KIT_COOLDOWN)) return 0;
        DynamicRegistryManager reg = ctx.getSource().getRegistryManager();

        // Броня (Защита I)
        giveArmor(p, reg, EquipmentSlot.HEAD, Items.IRON_HELMET);
        giveArmor(p, reg, EquipmentSlot.CHEST, Items.IRON_CHESTPLATE);
        giveArmor(p, reg, EquipmentSlot.LEGS, Items.IRON_LEGGINGS);
        giveArmor(p, reg, EquipmentSlot.FEET, Items.IRON_BOOTS);

        // Меч и кирка (Эффективность I, Прочность II)
        give(p, Items.IRON_SWORD, 1);
        ItemStack pick = new ItemStack(Items.IRON_PICKAXE);
        enchant(reg, pick, Enchantments.EFFICIENCY, 1);
        enchant(reg, pick, Enchantments.UNBREAKING, 2);
        p.getInventory().offerOrDrop(pick);

        // Еда
        give(p, Items.COOKED_BEEF, 16);

        // Дополнительные предметы (15)
        give(p, Items.GOLDEN_APPLE, 2);
        give(p, Items.ENDER_PEARL, 6);
        give(p, Items.SHIELD, 1);
        give(p, Items.IRON_AXE, 1);
        give(p, Items.IRON_SHOVEL, 1);
        give(p, Items.WATER_BUCKET, 1);
        give(p, Items.COBBLESTONE, 64);
        give(p, Items.OAK_PLANKS, 32);
        give(p, Items.TORCH, 32);
        give(p, Items.COBWEB, 8);
        give(p, Items.GOLDEN_CARROT, 16);
        give(p, Items.CRAFTING_TABLE, 1);
        give(p, Items.RED_BED, 1);
        give(p, Items.COAL, 16);
        give(p, Items.DIAMOND, 3);

        msg(p, "Вы получили стартовый набор!", Formatting.GREEN);
        return 1;
    }

    // ---------- homes ----------

    private static int setHome(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "sethome", SPAM_COOLDOWN)) return 0;

        String name = StringArgumentType.getString(ctx, "name");
        String dim = ctx.getSource().getWorld().getRegistryKey().getValue().toString();
        HomeStorage.set(p.getUuid(), name,
                new HomeStorage.Home(dim, p.getX(), p.getY(), p.getZ(), p.getYaw(), p.getPitch()));

        msg(p, "Дом «" + name + "» установлен.", Formatting.GREEN);
        return 1;
    }

    private static int home(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "home", SPAM_COOLDOWN)) return 0;

        String name = StringArgumentType.getString(ctx, "name");
        HomeStorage.Home h = HomeStorage.get(p.getUuid(), name);
        if (h == null) {
            msg(p, "Дом «" + name + "» не найден.", Formatting.RED);
            return 0;
        }
        ServerWorld world = ctx.getSource().getServer()
                .getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(h.dimension)));
        if (world == null) {
            msg(p, "Измерение этого дома недоступно.", Formatting.RED);
            return 0;
        }
        // Безопасная высота: если под точкой дома воздух, ставим игрока на первый твёрдый блок внизу
        double ty = h.y;
        BlockPos.Mutable m = new BlockPos.Mutable(MathHelper.floor(h.x), MathHelper.floor(h.y) - 1, MathHelper.floor(h.z));
        int bottom = world.getBottomY();
        for (int steps = 0; steps < 400 && m.getY() >= bottom; steps++) {
            BlockState below = world.getBlockState(m);
            if (below.getFluidState().isIn(FluidTags.WATER)) break; // падение в воду безопасно
            if (!below.getCollisionShape(world, m).isEmpty()) {
                double top = m.getY() + 1.0;
                if (h.y - top > 0.3) ty = top;
                break;
            }
            m.setY(m.getY() - 1);
        }
        p.teleport(world, h.x, ty, h.z, Set.of(), h.yaw, h.pitch, true);
        msg(p, "Вы телепортированы домой: " + name, Formatting.GREEN);
        return 1;
    }

    private static int delHome(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        String name = StringArgumentType.getString(ctx, "name");
        if (HomeStorage.remove(p.getUuid(), name)) {
            msg(p, "Дом «" + name + "» удалён.", Formatting.YELLOW);
            return 1;
        }
        msg(p, "Дом «" + name + "» не найден.", Formatting.RED);
        return 0;
    }

    private static int homes(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        var names = HomeStorage.names(p.getUuid());
        msg(p, names.isEmpty() ? "У вас нет домов." : "Ваши дома: " + String.join(", ", names), Formatting.AQUA);
        return 1;
    }
}
