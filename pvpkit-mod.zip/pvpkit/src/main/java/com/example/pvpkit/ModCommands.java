package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class ModCommands {
    private static final long SKILL_COOLDOWN = 15 * 60 * 1000L;
    private static final long KIT_COOLDOWN = 60 * 60 * 1000L;
    private static final long SPAM_COOLDOWN = 3 * 1000L;
    private static final int SKILL_TICKS = 45 * 20;

    private static final SuggestionProvider<ServerCommandSource> HOME_SUGGESTIONS = (ctx, builder) -> {
        ServerPlayerEntity p = ctx.getSource().getPlayer();
        if (p != null) CommandSource.suggestMatching(HomeStorage.names(p.getUuid()), builder);
        return builder.buildFuture();
    };

    private ModCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("skill").executes(ModCommands::skill));

        d.register(literal("kit")
                .then(literal("start").executes(ModCommands::kitStart)));

        d.register(literal("sethome")
                .then(argument("name", StringArgumentType.word()).executes(ModCommands::setHome)));

        d.register(literal("home")
                .then(argument("name", StringArgumentType.word())
                        .suggests(HOME_SUGGESTIONS)
                        .executes(ModCommands::home)));

        d.register(literal("delhome")
                .then(argument("name", StringArgumentType.word())
                        .suggests(HOME_SUGGESTIONS)
                        .executes(ModCommands::delHome)));

        d.register(literal("homes").executes(ModCommands::homes));
    }

    // ---------- helpers ----------

    private static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    /** true = можно выполнять, кулдаун запущен. */
    private static boolean useCooldown(ServerPlayerEntity p, String key, long millis) {
        long left = Cooldowns.remaining(p.getUuid(), key);
        if (left > 0) {
            msg(p, "Подождите ещё " + Cooldowns.format(left), Formatting.RED);
            return false;
        }
        Cooldowns.set(p.getUuid(), key, millis);
        return true;
    }

    // ---------- /skill ----------

    private static int skill(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "skill", SKILL_COOLDOWN)) return 0;

        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, SKILL_TICKS, 5)); // VI
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, SKILL_TICKS, 0));      // I
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, SKILL_TICKS, 1));   // II
        p.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, SKILL_TICKS, 1));      // II

        msg(p, "Скилл активирован на 45 секунд!", Formatting.GREEN);
        return 1;
    }

    // ---------- /kit start ----------

    private static ItemStack enchanted(ServerPlayerEntity p, Item item, int count,
                                       RegistryKey<Enchantment> key, int level) {
        ItemStack stack = new ItemStack(item, count);
        p.getServerWorld().getRegistryManager().get(RegistryKeys.ENCHANTMENT)
                .getEntry(key).ifPresent(e -> stack.addEnchantment(e, level));
        return stack;
    }

    private static void giveArmor(ServerPlayerEntity p, EquipmentSlot slot, Item item) {
        ItemStack stack = enchanted(p, item, 1, Enchantments.PROTECTION, 1);
        if (p.getEquippedStack(slot).isEmpty()) {
            p.equipStack(slot, stack);          // слот свободен — надеваем
        } else {
            p.getInventory().offerOrDrop(stack); // уже есть броня — кладём в инвентарь
        }
    }

    private static void give(ServerPlayerEntity p, Item item, int count) {
        p.getInventory().offerOrDrop(new ItemStack(item, count));
    }

    private static int kitStart(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "kit", KIT_COOLDOWN)) return 0;

        // Броня (Защита I)
        giveArmor(p, EquipmentSlot.HEAD, Items.IRON_HELMET);
        giveArmor(p, EquipmentSlot.CHEST, Items.IRON_CHESTPLATE);
        giveArmor(p, EquipmentSlot.LEGS, Items.IRON_LEGGINGS);
        giveArmor(p, EquipmentSlot.FEET, Items.IRON_BOOTS);

        // Оружие и инструменты
        give(p, Items.IRON_SWORD, 1);
        ItemStack pick = enchanted(p, Items.IRON_PICKAXE, 1, Enchantments.EFFICIENCY, 1); // Эффективность I
        p.getServerWorld().getRegistryManager().get(RegistryKeys.ENCHANTMENT)
                .getEntry(Enchantments.UNBREAKING).ifPresent(e -> pick.addEnchantment(e, 2)); // Прочность II
        p.getInventory().offerOrDrop(pick);

        // Еда
        give(p, Items.COOKED_BEEF, 32);

        // Дополнительные предметы
        give(p, Items.GOLDEN_APPLE, 8);
        give(p, Items.ENDER_PEARL, 4);
        give(p, Items.SHIELD, 1);
        p.getInventory().offerOrDrop(enchanted(p, Items.BOW, 1, Enchantments.UNBREAKING, 2));
        give(p, Items.ARROW, 32);
        give(p, Items.IRON_AXE, 1);
        give(p, Items.IRON_SHOVEL, 1);
        give(p, Items.WATER_BUCKET, 1);
        give(p, Items.COBBLESTONE, 64);
        give(p, Items.OAK_PLANKS, 64);
        give(p, Items.TORCH, 32);
        give(p, Items.COBWEB, 8);
        give(p, Items.GOLDEN_CARROT, 16);
        give(p, Items.EXPERIENCE_BOTTLE, 16);
        give(p, Items.SHEARS, 1);
        give(p, Items.FISHING_ROD, 1);
        give(p, Items.CRAFTING_TABLE, 1);
        give(p, Items.RED_BED, 1);
        give(p, Items.COAL, 32);
        give(p, Items.IRON_INGOT, 16);
        give(p, Items.DIAMOND, 3);

        msg(p, "Вы получили стартовый набор!", Formatting.GREEN);
        return 1;
    }

    // ---------- homes ----------

    private static int setHome(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "sethome", SPAM_COOLDOWN)) return 0;

        String name = StringArgumentType.getString(ctx, "name");
        String dim = p.getServerWorld().getRegistryKey().getValue().toString();
        HomeStorage.set(p.getUuid(), name,
                new HomeStorage.Home(dim, p.getX(), p.getY(), p.getZ(), p.getYaw(), p.getPitch()));

        msg(p, "Дом «" + name + "» установлен.", Formatting.GREEN);
        return 1;
    }

    private static int home(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        if (!useCooldown(p, "home", SPAM_COOLDOWN)) return 0;

        String name = StringArgumentType.getString(ctx, "name");
        HomeStorage.Home h = HomeStorage.get(p.getUuid(), name);
        if (h == null) {
            msg(p, "Дом «" + name + "» не найден.", Formatting.RED);
            return 0;
        }
        ServerWorld world = ctx.getSource().getServer()
                .getWorld(RegistryKey.of(RegistryKeys.WORLD, Identifier.of(h.dimension)));
        if (world == null) {
            msg(p, "Измерение этого дома недоступно.", Formatting.RED);
            return 0;
        }
        p.teleport(world, h.x, h.y, h.z, h.yaw, h.pitch);
        msg(p, "Вы телепортированы домой: " + name, Formatting.GREEN);
        return 1;
    }

    private static int delHome(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        String name = StringArgumentType.getString(ctx, "name");
        if (HomeStorage.remove(p.getUuid(), name)) {
            msg(p, "Дом «" + name + "» удалён.", Formatting.YELLOW);
            return 1;
        }
        msg(p, "Дом «" + name + "» не найден.", Formatting.RED);
        return 0;
    }

    private static int homes(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        var names = HomeStorage.names(p.getUuid());
        msg(p, names.isEmpty() ? "У вас нет домов." : "Ваши дома: " + String.join(", ", names), Formatting.AQUA);
        return 1;
    }
}
