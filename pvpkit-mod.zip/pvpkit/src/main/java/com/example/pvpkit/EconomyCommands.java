package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class EconomyCommands {
    private static final int PAGE_SIZE = 8;

    private static final SuggestionProvider<ServerCommandSource> ITEM_SUGGESTIONS = (ctx, builder) -> {
        CommandSource.suggestMatching(Shop.ITEMS.stream().map(Shop.Entry::id).toList(), builder);
        return builder.buildFuture();
    };

    private EconomyCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("balance").executes(EconomyCommands::balance));

        d.register(literal("shop")
                .executes(ctx -> shop(ctx, 1))
                .then(argument("page", IntegerArgumentType.integer(1))
                        .executes(ctx -> shop(ctx, IntegerArgumentType.getInteger(ctx, "page")))));

        d.register(literal("buy")
                .then(argument("item", StringArgumentType.word())
                        .suggests(ITEM_SUGGESTIONS)
                        .executes(ctx -> buy(ctx, 1))
                        .then(argument("amount", IntegerArgumentType.integer(1, 16))
                                .executes(ctx -> buy(ctx, IntegerArgumentType.getInteger(ctx, "amount"))))));

        d.register(literal("pay")
                .then(argument("player", EntityArgumentType.player())
                        .then(argument("amount", LongArgumentType.longArg(1))
                                .executes(EconomyCommands::pay))));

        // Выдача коинов — только из консоли сервера
        d.register(literal("eco")
                .then(literal("give")
                        .then(argument("player", EntityArgumentType.player())
                                .then(argument("amount", LongArgumentType.longArg(1))
                                        .executes(EconomyCommands::ecoGive)))));
    }

    private static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    private static int balance(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        msg(p, "Ваш баланс: " + Economy.balance(p.getUuid()) + " коинов", Formatting.GOLD);
        return 1;
    }

    private static int shop(CommandContext<ServerCommandSource> ctx, int page) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        int pages = (Shop.ITEMS.size() + PAGE_SIZE - 1) / PAGE_SIZE;
        if (page > pages) page = pages;

        msg(p, "=== Магазин, страница " + page + "/" + pages + " ===", Formatting.AQUA);
        int from = (page - 1) * PAGE_SIZE;
        int to = Math.min(from + PAGE_SIZE, Shop.ITEMS.size());
        for (int i = from; i < to; i++) {
            Shop.Entry e = Shop.ITEMS.get(i);
            msg(p, e.id() + " — " + e.name() + (e.count() > 1 ? " x" + e.count() : "")
                    + " — " + e.price() + " коинов", Formatting.YELLOW);
        }
        msg(p, "Купить: /buy <id> [кол-во]. Следующая страница: /shop " + Math.min(page + 1, pages), Formatting.GRAY);
        return 1;
    }

    private static int buy(CommandContext<ServerCommandSource> ctx, int amount) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        String id = StringArgumentType.getString(ctx, "item");
        Shop.Entry e = Shop.find(id);
        if (e == null) {
            msg(p, "Такого товара нет. Список: /shop", Formatting.RED);
            return 0;
        }
        long total = e.price() * amount;
        if (!Economy.take(p.getUuid(), total)) {
            msg(p, "Не хватает коинов. Нужно " + total + ", у вас " + Economy.balance(p.getUuid()), Formatting.RED);
            return 0;
        }
        DynamicRegistryManager reg = ctx.getSource().getRegistryManager();
        for (int i = 0; i < amount; i++) {
            p.getInventory().offerOrDrop(e.create(reg));
        }
        msg(p, "Куплено: " + e.name() + " x" + (e.count() * amount) + " за " + total + " коинов. Баланс: "
                + Economy.balance(p.getUuid()), Formatting.GREEN);
        return 1;
    }

    private static int pay(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        if (target.getUuid().equals(p.getUuid())) {
            msg(p, "Нельзя переводить себе.", Formatting.RED);
            return 0;
        }
        if (!Economy.take(p.getUuid(), amount)) {
            msg(p, "Не хватает коинов.", Formatting.RED);
            return 0;
        }
        Economy.add(target.getUuid(), amount);
        msg(p, "Переведено " + amount + " коинов. Баланс: " + Economy.balance(p.getUuid()), Formatting.GREEN);
        msg(target, "Вам перевели " + amount + " коинов. Баланс: " + Economy.balance(target.getUuid()), Formatting.GOLD);
        return 1;
    }

    private static int ecoGive(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        if (ctx.getSource().getPlayer() != null) {
            ctx.getSource().sendError(Text.literal("Эту команду можно выполнить только из консоли сервера."));
            return 0;
        }
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        Economy.add(target.getUuid(), amount);
        msg(target, "Вам выдали " + amount + " коинов. Баланс: " + Economy.balance(target.getUuid()), Formatting.GOLD);
        return 1;
    }
}
