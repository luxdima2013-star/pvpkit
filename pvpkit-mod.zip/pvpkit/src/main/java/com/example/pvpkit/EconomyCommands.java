package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class EconomyCommands {
    private EconomyCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("balance").executes(EconomyCommands::balance));

        // /shop — меню, /shop <текст> — поиск (по-русски или по-английски, часть слова тоже подойдёт)
        d.register(literal("shop")
                .executes(ctx -> openShop(ctx, null))
                .then(argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> openShop(ctx, StringArgumentType.getString(ctx, "text")))));

        d.register(literal("pay")
                .then(argument("player", EntityArgumentType.player())
                        .then(argument("amount", LongArgumentType.longArg(1))
                                .executes(EconomyCommands::pay))));

        // Выдача коинов — только из консоли сервера
        d.register(literal("eco")
                .then(literal("give")
                        .then(argument("player", EntityArgumentType.player())
                                .then(argument("amount", LongArgumentType.longArg(1))
                                        .executes(EconomyCommands::ecoGive)))));
    }

    private static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    private static int openShop(CommandContext<ServerCommandSource> ctx, String search) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ShopMenu.open(p, ctx.getSource().getRegistryManager(), search);
        return 1;
    }

    private static int balance(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        msg(p, "Ваш баланс: " + Economy.balance(p.getUuid()) + " коинов", Formatting.GOLD);
        return 1;
    }

    private static int pay(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        if (target.getUuid().equals(p.getUuid())) {
            msg(p, "Нельзя переводить себе.", Formatting.RED);
            return 0;
        }
        if (!Economy.take(p.getUuid(), amount)) {
            msg(p, "Не хватает коинов.", Formatting.RED);
            return 0;
        }
        Economy.add(target.getUuid(), amount);
        msg(p, "Переведено " + amount + " коинов. Баланс: " + Economy.balance(p.getUuid()), Formatting.GREEN);
        msg(target, "Вам перевели " + amount + " коинов. Баланс: " + Economy.balance(target.getUuid()), Formatting.GOLD);
        return 1;
    }

    private static int ecoGive(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        if (ctx.getSource().getPlayer() != null) {
            ctx.getSource().sendError(Text.literal("Эту команду можно выполнить только из консоли сервера."));
            return 0;
        }
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        Economy.add(target.getUuid(), amount);
        msg(target, "Вам выдали " + amount + " коинов. Баланс: " + Economy.balance(target.getUuid()), Formatting.GOLD);
        return 1;
    }
}
