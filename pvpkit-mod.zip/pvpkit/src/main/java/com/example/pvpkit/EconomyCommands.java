package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public final class EconomyCommands {
    private EconomyCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("balance").executes(EconomyCommands::balance));
        d.register(literal("daily").executes(EconomyCommands::daily));
        d.register(literal("earn").executes(EconomyCommands::earn));
        d.register(literal("sell")
                .executes(ctx -> sell(ctx, false))
                .then(literal("all").executes(ctx -> sell(ctx, true))));

        // /shop — меню, /shop <текст> — поиск (по-русски или по-английски, часть слова тоже подойдёт)
        d.register(literal("shop")
                .executes(ctx -> openShop(ctx, null))
                .then(argument("text", StringArgumentType.greedyString())
                        .executes(ctx -> openShop(ctx, StringArgumentType.getString(ctx, "text")))));

        d.register(literal("pay")
                .then(argument("player", EntityArgumentType.player())
                        .then(argument("amount", LongArgumentType.longArg(1))
                                .executes(EconomyCommands::pay))));

        // Выдача коинов — только из консоли сервера
        d.register(literal("eco")
                .then(literal("give")
                        .then(argument("player", EntityArgumentType.player())
                                .then(argument("amount", LongArgumentType.longArg(1))
                                        .executes(EconomyCommands::ecoGive)))));
    }

    private static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    private static int openShop(CommandContext<ServerCommandSource> ctx, String search) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ShopMenu.open(p, ctx.getSource().getRegistryManager(), search);
        return 1;
    }

    private static int earn(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        msg(p, "=== Как заработать коины ===", Formatting.AQUA);
        msg(p, "• Убивать враждебных мобов", Formatting.YELLOW);
        msg(p, "• Добывать руду (уголь, железо, алмазы, древние обломки и др.)", Formatting.YELLOW);
        msg(p, "• /daily — бонус раз в 24 часа (" + Earnings.DAILY_REWARD + " коинов)", Formatting.YELLOW);
        msg(p, "• Просто играть: +" + Earnings.PLAYTIME_REWARD + " коинов каждые 10 минут на сервере", Formatting.YELLOW);
        msg(p, "• /sell — продать предмет из руки, /sell all — продать всё подходящее из инвентаря", Formatting.YELLOW);
        return 1;
    }

    private static int daily(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        long left = Cooldowns.remaining(p.getUuid(), "daily");
        if (left > 0) {
            msg(p, "Ежедневный бонус уже получен. Подождите ещё " + Cooldowns.format(left), Formatting.RED);
            return 0;
        }
        Cooldowns.set(p.getUuid(), "daily", Earnings.DAILY_COOLDOWN_MS);
        Economy.add(p.getUuid(), Earnings.DAILY_REWARD);
        msg(p, "Ежедневный бонус: +" + Earnings.DAILY_REWARD + " коинов. Баланс: " + Economy.balance(p.getUuid()),
                Formatting.GOLD);
        return 1;
    }

    private static boolean sellable(ItemStack stack) {
        if (stack.isEmpty() || stack.isDamaged()) return false;
        var enchants = stack.get(DataComponentTypes.ENCHANTMENTS);
        if (enchants != null && !enchants.isEmpty()) return false;
        return Earnings.sellPrice(stack.getItem()) != null;
    }

    private static int sell(CommandContext<ServerCommandSource> ctx, boolean all) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        long total = 0;
        int items = 0;

        if (all) {
            for (int i = 0; i < 36; i++) {
                ItemStack st = p.getInventory().getStack(i);
                if (!sellable(st)) continue;
                total += Earnings.sellPrice(st.getItem()) * st.getCount();
                items += st.getCount();
                p.getInventory().setStack(i, ItemStack.EMPTY);
            }
        } else {
            ItemStack st = p.getMainHandStack();
            if (!sellable(st)) {
                msg(p, "Этот предмет не принимается. Возьмите в руку то, что хотите продать (мобьи дропы, руда, слитки, урожай). Список способов: /earn",
                        Formatting.RED);
                return 0;
            }
            total = Earnings.sellPrice(st.getItem()) * st.getCount();
            items = st.getCount();
            p.setStackInHand(Hand.MAIN_HAND, ItemStack.EMPTY);
        }

        if (items == 0) {
            msg(p, "В инвентаре нет подходящих предметов для продажи.", Formatting.RED);
            return 0;
        }
        Economy.add(p.getUuid(), total);
        msg(p, "Продано предметов: " + items + ", получено " + total + " коинов. Баланс: "
                + Economy.balance(p.getUuid()), Formatting.GREEN);
        return 1;
    }

    private static int balance(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        msg(p, "Ваш баланс: " + Economy.balance(p.getUuid()) + " коинов", Formatting.GOLD);
        return 1;
    }

    private static int pay(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        if (target.getUuid().equals(p.getUuid())) {
            msg(p, "Нельзя переводить себе.", Formatting.RED);
            return 0;
        }
        if (!Economy.take(p.getUuid(), amount)) {
            msg(p, "Не хватает коинов.", Formatting.RED);
            return 0;
        }
        Economy.add(target.getUuid(), amount);
        msg(p, "Переведено " + amount + " коинов. Баланс: " + Economy.balance(p.getUuid()), Formatting.GREEN);
        msg(target, "Вам перевели " + amount + " коинов. Баланс: " + Economy.balance(target.getUuid()), Formatting.GOLD);
        return 1;
    }

    private static int ecoGive(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        if (ctx.getSource().getPlayer() != null) {
            ctx.getSource().sendError(Text.literal("Эту команду можно выполнить только из консоли сервера."));
            return 0;
        }
        ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
        long amount = LongArgumentType.getLong(ctx, "amount");
        Economy.add(target.getUuid(), amount);
        msg(target, "Вам выдали " + amount + " коинов. Баланс: " + Economy.balance(target.getUuid()), Formatting.GOLD);
        return 1;
    }
}
