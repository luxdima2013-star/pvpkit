package com.example.pvpkit;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;

/** Способы заработка: руда, время на сервере, продажа предметов (/sell), ежедневный бонус (/daily). */
public final class Earnings {
    public static final long DAILY_REWARD = 1000;
    public static final long DAILY_COOLDOWN_MS = 24L * 60 * 60 * 1000;
    public static final long PLAYTIME_REWARD = 100;
    private static final int PLAYTIME_TICKS = 20 * 60 * 10; // каждые 10 минут

    private static final Map<String, Long> ORE = new HashMap<>();
    /** Цена продажи за 1 штуку. Всё, чего нет в списке, не принимается. */
    private static final Map<String, Long> SELL = new HashMap<>();

    static {
        ORE.put("coal_ore", 2L);
        ORE.put("copper_ore", 3L);
        ORE.put("iron_ore", 5L);
        ORE.put("gold_ore", 10L);
        ORE.put("nether_gold_ore", 6L);
        ORE.put("lapis_ore", 8L);
        ORE.put("redstone_ore", 4L);
        ORE.put("nether_quartz_ore", 5L);
        ORE.put("emerald_ore", 40L);
        ORE.put("diamond_ore", 40L);
        ORE.put("ancient_debris", 200L);

        // мобы
        sell("rotten_flesh", 2); sell("bone", 3); sell("string", 3); sell("spider_eye", 4);
        sell("gunpowder", 6); sell("slime_ball", 8); sell("leather", 4); sell("feather", 2);
        sell("ink_sac", 3); sell("glow_ink_sac", 8); sell("phantom_membrane", 40); sell("ghast_tear", 80);
        sell("blaze_rod", 40); sell("blaze_powder", 20); sell("magma_cream", 8); sell("ender_pearl", 60);
        sell("breeze_rod", 30); sell("prismarine_shard", 5); sell("nautilus_shell", 150);
        sell("turtle_scute", 20); sell("armadillo_scute", 20); sell("echo_shard", 100);
        sell("heart_of_the_sea", 500); sell("totem_of_undying", 300);
        // ресурсы
        sell("coal", 3); sell("charcoal", 3); sell("raw_iron", 6); sell("iron_ingot", 10);
        sell("raw_copper", 3); sell("copper_ingot", 4); sell("raw_gold", 12); sell("gold_ingot", 20);
        sell("lapis_lazuli", 8); sell("redstone", 4); sell("quartz", 6); sell("amethyst_shard", 5);
        sell("emerald", 150); sell("diamond", 250); sell("netherite_scrap", 400);
        sell("ancient_debris", 600); sell("obsidian", 15); sell("nether_wart", 3);
        // ферма и рыба
        sell("wheat", 2); sell("carrot", 2); sell("potato", 2); sell("beetroot", 2);
        sell("sweet_berries", 2); sell("melon_slice", 1); sell("pumpkin", 3); sell("sugar_cane", 1);
        sell("kelp", 1); sell("cactus", 1); sell("bamboo", 1); sell("honeycomb", 3); sell("honey_bottle", 6);
        sell("cod", 4); sell("salmon", 5); sell("tropical_fish", 20); sell("pufferfish", 15);
    }

    private static void sell(String id, long price) {
        SELL.put(id, price);
    }

    private Earnings() {}

    /** Цена продажи за 1 штуку или null, если предмет не принимается. */
    public static Long sellPrice(Item item) {
        return SELL.get(Registries.ITEM.getId(item).getPath());
    }

    private static int tick = 0;

    public static void init() {
        // Награда за добычу руды
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof ServerPlayerEntity sp) || sp.isCreative()) return;
            String path = Registries.BLOCK.getId(state.getBlock()).getPath();
            if (path.startsWith("deepslate_")) path = path.substring("deepslate_".length());
            Long reward = ORE.get(path);
            if (reward == null) return;
            Economy.add(sp.getUuid(), reward);
            sp.sendMessage(Text.literal("+" + reward + " коинов (баланс: " + Economy.balance(sp.getUuid()) + ")")
                    .formatted(Formatting.GOLD), true);
        });

        // Награда за время на сервере
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++tick < PLAYTIME_TICKS) return;
            tick = 0;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                Economy.add(p.getUuid(), PLAYTIME_REWARD);
                p.sendMessage(Text.literal("+" + PLAYTIME_REWARD + " коинов за время на сервере (баланс: "
                        + Economy.balance(p.getUuid()) + ")").formatted(Formatting.GOLD), false);
            }
        });
    }
}
