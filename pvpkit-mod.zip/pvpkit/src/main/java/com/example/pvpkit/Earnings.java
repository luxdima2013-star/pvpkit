package com.example.pvpkit;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.block.CropBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Способы заработка. Список для игроков — команда /earn. */
public final class Earnings {
    public static final long DAILY_BASE = 1000;
    public static final long DAILY_STEP = 250;      // +250 за каждый день серии (до 7 дней)
    public static final long DAILY_COOLDOWN_MS = 24L * 60 * 60 * 1000;
    public static final long WEEKLY_REWARD = 10000;
    public static final long WEEKLY_COOLDOWN_MS = 7L * 24 * 60 * 60 * 1000;
    public static final long PLAYTIME_REWARD = 100;
    public static final long LEVEL_REWARD = 25;     // за каждый новый уровень опыта
    public static final long BIOME_REWARD = 150;
    public static final long PVP_REWARD = 500;
    public static final long PVP_REPEAT_COOLDOWN_MS = 10L * 60 * 1000; // за одного и того же игрока — раз в 10 минут
    private static final int PLAYTIME_TICKS = 20 * 60 * 10; // каждые 10 минут

    private static final Map<String, Long> ORE = new HashMap<>();
    private static final Map<String, Long> CROPS = new HashMap<>();
    /** Цена продажи за 1 штуку. Всё, чего нет в списке, не принимается. */
    private static final Map<String, Long> SELL = new HashMap<>();
    /** Комбо убийств мобов: [время последнего убийства, номер комбо]. */
    private static final Map<UUID, long[]> COMBO = new HashMap<>();

    static {
        ORE.put("coal_ore", 2L);
        ORE.put("copper_ore", 3L);
        ORE.put("iron_ore", 5L);
        ORE.put("gold_ore", 10L);
        ORE.put("nether_gold_ore", 6L);
        ORE.put("lapis_ore", 8L);
        ORE.put("redstone_ore", 4L);
        ORE.put("nether_quartz_ore", 5L);
        ORE.put("emerald_ore", 40L);
        ORE.put("diamond_ore", 40L);
        ORE.put("ancient_debris", 200L);

        CROPS.put("wheat", 2L);
        CROPS.put("carrots", 2L);
        CROPS.put("potatoes", 2L);
        CROPS.put("beetroots", 2L);
        CROPS.put("nether_wart", 3L);

        // мобы
        sell("rotten_flesh", 2); sell("bone", 3); sell("string", 3); sell("spider_eye", 4);
        sell("gunpowder", 6); sell("slime_ball", 8); sell("leather", 4); sell("feather", 2);
        sell("ink_sac", 3); sell("glow_ink_sac", 8); sell("phantom_membrane", 40); sell("ghast_tear", 80);
        sell("blaze_rod", 40); sell("blaze_powder", 20); sell("magma_cream", 8); sell("ender_pearl", 60);
        sell("breeze_rod", 30); sell("prismarine_shard", 5); sell("nautilus_shell", 150);
        sell("turtle_scute", 20); sell("armadillo_scute", 20); sell("echo_shard", 100);
        sell("heart_of_the_sea", 500); sell("totem_of_undying", 300);
        // ресурсы
        sell("coal", 3); sell("charcoal", 3); sell("raw_iron", 6); sell("iron_ingot", 10);
        sell("raw_copper", 3); sell("copper_ingot", 4); sell("raw_gold", 12); sell("gold_ingot", 20);
        sell("lapis_lazuli", 8); sell("redstone", 4); sell("quartz", 6); sell("amethyst_shard", 5);
        sell("emerald", 150); sell("diamond", 250); sell("netherite_scrap", 400);
        sell("ancient_debris", 600); sell("obsidian", 15); sell("nether_wart", 3);
        // ферма и рыба
        sell("wheat", 2); sell("carrot", 2); sell("potato", 2); sell("beetroot", 2);
        sell("sweet_berries", 2); sell("melon_slice", 1); sell("pumpkin", 3); sell("sugar_cane", 1);
        sell("kelp", 1); sell("cactus", 1); sell("bamboo", 1); sell("honeycomb", 3); sell("honey_bottle", 6);
        sell("cod", 4); sell("salmon", 5); sell("tropical_fish", 20); sell("pufferfish", 15);
    }

    private static void sell(String id, long price) {
        SELL.put(id, price);
    }

    private Earnings() {}

    /** Цена продажи за 1 штуку или null, если предмет не принимается. */
    public static Long sellPrice(Item item) {
        return SELL.get(Registries.ITEM.getId(item).getPath());
    }

    private static void reward(ServerPlayerEntity p, long amount, String reason, boolean actionBar) {
        Economy.add(p.getUuid(), amount);
        p.sendMessage(Text.literal("+" + amount + " коинов" + (reason.isEmpty() ? "" : " — " + reason)
                + " (баланс: " + Economy.balance(p.getUuid()) + ")").formatted(Formatting.GOLD), actionBar);
    }

    // ---------- /daily ----------

    /** Возвращает {награда, серия дней}. Вызывать только когда кулдаун /daily закончился. */
    public static long[] claimDaily(ServerPlayerEntity p) {
        Progress.Data d = Progress.get(p.getUuid());
        long now = System.currentTimeMillis();
        if (d.lastDaily == 0 || now - d.lastDaily > 2 * DAILY_COOLDOWN_MS) d.streak = 0; // серия прервалась
        d.streak = Math.min(d.streak + 1, 7);
        d.lastDaily = now;
        Progress.save();
        long reward = DAILY_BASE + DAILY_STEP * (d.streak - 1);
        Economy.add(p.getUuid(), reward);
        return new long[]{reward, d.streak};
    }

    // ---------- комбо за мобов ----------

    /** Каждое следующее убийство моба в течение 8 секунд даёт +10% (максимум +100%). */
    public static long applyCombo(ServerPlayerEntity p, long base) {
        long now = System.currentTimeMillis();
        long[] st = COMBO.computeIfAbsent(p.getUuid(), k -> new long[2]);
        if (now - st[0] <= 8000) st[1] = Math.min(st[1] + 1, 10);
        else st[1] = 0;
        st[0] = now;
        return base + base * st[1] / 10;
    }

    public static long comboLevel(ServerPlayerEntity p) {
        long[] st = COMBO.get(p.getUuid());
        return st == null ? 0 : st[1];
    }

    // ---------- убийство игрока ----------

    public static void pvpKill(ServerPlayerEntity killer, ServerPlayerEntity victim) {
        String key = "pvp:" + victim.getUuid();
        if (Cooldowns.remaining(killer.getUuid(), key) > 0) return; // защита от накрутки между друзьями
        Cooldowns.set(killer.getUuid(), key, PVP_REPEAT_COOLDOWN_MS);
        reward(killer, PVP_REWARD, "за убийство игрока", false);
    }

    // ---------- события ----------

    private static ServerWorld worldOf(MinecraftServer server, ServerPlayerEntity p) {
        for (ServerWorld w : server.getWorlds()) {
            if (w.getPlayers().contains(p)) return w;
        }
        return null;
    }

    public static void init() {
        // Руда и созревший урожай
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof ServerPlayerEntity sp) || sp.isCreative()) return;
            String path = Registries.BLOCK.getId(state.getBlock()).getPath();
            if (path.startsWith("deepslate_")) path = path.substring("deepslate_".length());

            Long reward = ORE.get(path);
            if (reward != null) {
                reward(sp, reward, "", true);
                return;
            }
            Long crop = CROPS.get(path);
            if (crop != null) {
                boolean mature = state.getBlock() instanceof CropBlock cb
                        ? cb.isMature(state)
                        : path.equals("nether_wart") && state.get(NetherWartBlock.AGE) >= 3;
                if (mature) reward(sp, crop, "", true);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.getTicks();

            // за время на сервере
            if (t % PLAYTIME_TICKS == 0) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    reward(p, PLAYTIME_REWARD, "за время на сервере", false);
                }
            }

            // за новые уровни опыта (только выше максимума, который был)
            if (t % 20 == 0) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    Progress.Data d = Progress.get(p.getUuid());
                    int lvl = p.experienceLevel;
                    if (d.maxLevel == 0 && lvl > 0) {
                        d.maxLevel = lvl;
                        Progress.save();
                    } else if (lvl > d.maxLevel) {
                        long amount = (lvl - d.maxLevel) * LEVEL_REWARD;
                        d.maxLevel = lvl;
                        Progress.save();
                        reward(p, amount, "за новый уровень опыта", true);
                    }
                }
            }

            // исследование: новые биомы и измерения
            if (t % 100 == 0) {
                for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                    ServerWorld w = worldOf(server, p);
                    if (w == null) continue;
                    Progress.Data d = Progress.get(p.getUuid());

                    String dim = w.getRegistryKey().getValue().toString();
                    if (d.dims.add(dim)) {
                        Progress.save();
                        if (dim.equals("minecraft:the_nether")) reward(p, 1000, "первый визит в Незер", false);
                        else if (dim.equals("minecraft:the_end")) reward(p, 3000, "первый визит в Энд", false);
                    }

                    String biome = w.getBiome(p.getBlockPos()).getKey()
                            .map(k -> k.getValue().toString()).orElse(null);
                    if (biome != null && d.biomes.add(biome)) {
                        Progress.save();
                        String[] parts = biome.split(":", 2);
                        Text name = Text.translatable("biome." + parts[0] + "." + parts[parts.length - 1]);
                        Economy.add(p.getUuid(), BIOME_REWARD);
                        p.sendMessage(Text.literal("Новый биом: ").append(name)
                                .append(Text.literal(" +" + BIOME_REWARD + " коинов")).formatted(Formatting.GOLD), false);
                    }
                }
            }
        });
    }
}
