package com.example.pvpkit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class HomeStorage {
    public static class Home {
        public String dimension;
        public double x, y, z;
        public float yaw, pitch;

        public Home(String dimension, double x, double y, double z, float yaw, float pitch) {
            this.dimension = dimension;
            this.x = x; this.y = y; this.z = z;
            this.yaw = yaw; this.pitch = pitch;
        }
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<Map<String, Map<String, Home>>>() {}.getType();
    private static Map<String, Map<String, Home>> data = new HashMap<>();

    private HomeStorage() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvpkit-homes.json");
    }

    public static synchronized void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Map<String, Map<String, Home>> loaded = GSON.fromJson(Files.readString(f), TYPE);
                if (loaded != null) data = loaded;
            }
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось загрузить дома", e);
        }
    }

    private static void save() {
        try {
            Files.writeString(file(), GSON.toJson(data, TYPE));
        } catch (IOException e) {
            PvpKitMod.LOGGER.error("Не удалось сохранить дома", e);
        }
    }

    public static synchronized void set(UUID player, String name, Home home) {
        data.computeIfAbsent(player.toString(), k -> new HashMap<>()).put(name.toLowerCase(), home);
        save();
    }

    public static synchronized Home get(UUID player, String name) {
        Map<String, Home> m = data.get(player.toString());
        return m == null ? null : m.get(name.toLowerCase());
    }

    public static synchronized boolean remove(UUID player, String name) {
        Map<String, Home> m = data.get(player.toString());
        if (m == null || m.remove(name.toLowerCase()) == null) return false;
        save();
        return true;
    }

    public static synchronized List<String> names(UUID player) {
        Map<String, Home> m = data.get(player.toString());
        return m == null ? List.of() : new ArrayList<>(m.keySet());
    }
}
