package com.example.pvpkit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.serialization.JsonOps;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryOps;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Аукцион игроков.
 * /ah — меню лотов; /ah sell <цена> — выставить предмет из руки (вся стопка);
 * /ah claim — забрать вернувшиеся предметы (лот истёк).
 * Комиссия за выставление 2% (минимум 10), налог с продажи 5%, лот живёт 48 часов, не больше 5 лотов у игрока.
 */
public final class Auction {
    public static final int MAX_LOTS = 5;
    public static final long DURATION_MS = 48L * 60 * 60 * 1000;
    public static final int TAX_PERCENT = 5;
    public static final int LISTING_FEE_PERCENT = 2;
    public static final long MAX_PRICE = 100_000_000L;

    public record Lot(long id, UUID seller, String sellerName, long price, long expiry, ItemStack stack) {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final List<Lot> LOTS = new ArrayList<>();
    private static final Map<UUID, List<ItemStack>> CLAIMS = new HashMap<>();
    private static long nextId = 1;
    static MinecraftServer server;

    private Auction() {}

    // ---------- сохранение ----------

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvpkit-auction.json");
    }

    private static RegistryOps<JsonElement> ops() {
        return server.getRegistryManager().getOps(JsonOps.INSTANCE);
    }

    private static JsonElement encode(ItemStack stack) {
        return ItemStack.CODEC.encodeStart(ops(), stack).getOrThrow();
    }

    private static ItemStack decode(JsonElement el) {
        return ItemStack.CODEC.parse(ops(), el).getOrThrow();
    }

    private static void save() {
        if (server == null) return;
        try {
            JsonObject root = new JsonObject();
            root.addProperty("nextId", nextId);
            JsonArray lots = new JsonArray();
            for (Lot l : LOTS) {
                JsonObject o = new JsonObject();
                o.addProperty("id", l.id());
                o.addProperty("seller", l.seller().toString());
                o.addProperty("sellerName", l.sellerName());
                o.addProperty("price", l.price());
                o.addProperty("expiry", l.expiry());
                o.add("item", encode(l.stack()));
                lots.add(o);
            }
            root.add("lots", lots);
            JsonObject claims = new JsonObject();
            for (Map.Entry<UUID, List<ItemStack>> e : CLAIMS.entrySet()) {
                JsonArray arr = new JsonArray();
                for (ItemStack st : e.getValue()) arr.add(encode(st));
                claims.add(e.getKey().toString(), arr);
            }
            root.add("claims", claims);
            Files.writeString(file(), GSON.toJson(root));
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось сохранить аукцион", e);
        }
    }

    private static void load() {
        LOTS.clear();
        CLAIMS.clear();
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            nextId = root.get("nextId").getAsLong();
            for (JsonElement el : root.getAsJsonArray("lots")) {
                JsonObject o = el.getAsJsonObject();
                LOTS.add(new Lot(o.get("id").getAsLong(), UUID.fromString(o.get("seller").getAsString()),
                        o.get("sellerName").getAsString(), o.get("price").getAsLong(), o.get("expiry").getAsLong(),
                        decode(o.get("item"))));
            }
            JsonObject claims = root.getAsJsonObject("claims");
            for (Map.Entry<String, JsonElement> e : claims.entrySet()) {
                List<ItemStack> list = new ArrayList<>();
                for (JsonElement el : e.getValue().getAsJsonArray()) list.add(decode(el));
                CLAIMS.put(UUID.fromString(e.getKey()), list);
            }
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось загрузить аукцион", e);
        }
    }

    // ---------- события ----------

    public static void init() {
        ServerLifecycleEvents.SERVER_STARTED.register(s -> {
            server = s;
            load();
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> save());
        ServerLifecycleEvents.SERVER_STOPPED.register(s -> server = null);

        // Раз в минуту: просроченные лоты возвращаются продавцу
        ServerTickEvents.END_SERVER_TICK.register(srv -> {
            if (srv.getTicks() % 1200 != 0 || LOTS.isEmpty()) return;
            long now = System.currentTimeMillis();
            boolean changed = false;
            for (Iterator<Lot> it = LOTS.iterator(); it.hasNext(); ) {
                Lot l = it.next();
                if (l.expiry() > now) continue;
                it.remove();
                CLAIMS.computeIfAbsent(l.seller(), k -> new ArrayList<>()).add(l.stack().copy());
                changed = true;
                ServerPlayerEntity p = srv.getPlayerManager().getPlayer(l.seller());
                if (p != null) p.sendMessage(Text.literal("Ваш лот на аукционе истёк. Заберите предмет: /ah claim")
                        .formatted(Formatting.YELLOW), false);
            }
            if (changed) save();
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, srv) -> {
            List<ItemStack> c = CLAIMS.get(handler.player.getUuid());
            if (c != null && !c.isEmpty()) {
                handler.player.sendMessage(Text.literal("На аукционе вас ждут предметы: /ah claim")
                        .formatted(Formatting.YELLOW), false);
            }
        });
    }

    // ---------- доступ для меню ----------

    public static List<Lot> lots(UUID viewer, boolean mineOnly) {
        List<Lot> out = new ArrayList<>();
        for (int i = LOTS.size() - 1; i >= 0; i--) { // новые сверху
            Lot l = LOTS.get(i);
            if (!mineOnly || l.seller().equals(viewer)) out.add(l);
        }
        return out;
    }

    /** true, если лот ещё был на аукционе и теперь снят. */
    public static boolean remove(Lot lot) {
        boolean ok = LOTS.remove(lot);
        if (ok) save();
        return ok;
    }

    /** Вернуть лот на аукцион (если покупка не состоялась). */
    public static void restore(Lot lot) {
        LOTS.add(lot);
        save();
    }

    // ---------- команды ----------

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(root("ah"));
        d.register(root("auction"));
    }

    private static LiteralArgumentBuilder<ServerCommandSource> root(String name) {
        return literal(name)
                .executes(ctx -> {
                    AuctionMenu.open(ctx.getSource().getPlayerOrThrow());
                    return 1;
                })
                .then(literal("sell").then(argument("price", LongArgumentType.longArg(1, MAX_PRICE))
                        .executes(Auction::sell)))
                .then(literal("claim").executes(Auction::claim));
    }

    private static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    private static int sell(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        long price = LongArgumentType.getLong(ctx, "price");
        ItemStack hand = p.getMainHandStack();
        if (hand.isEmpty()) {
            msg(p, "Возьмите в руку предмет, который хотите выставить.", Formatting.RED);
            return 0;
        }
        int mine = 0;
        for (Lot l : LOTS) if (l.seller().equals(p.getUuid())) mine++;
        if (mine >= MAX_LOTS) {
            msg(p, "У вас уже " + MAX_LOTS + " лотов. Снимите один или дождитесь продажи.", Formatting.RED);
            return 0;
        }
        long fee = Math.max(10, price * LISTING_FEE_PERCENT / 100);
        if (!Economy.take(p.getUuid(), fee)) {
            msg(p, "Не хватает коинов на комиссию за выставление: " + fee, Formatting.RED);
            return 0;
        }
        Lot lot = new Lot(nextId++, p.getUuid(), p.getName().getString(), price,
                System.currentTimeMillis() + DURATION_MS, hand.copy());
        p.setStackInHand(Hand.MAIN_HAND, ItemStack.EMPTY);
        LOTS.add(lot);
        save();
        msg(p, "Лот выставлен за " + price + " коинов (комиссия " + fee + "). Лот живёт 48 часов. Меню: /ah",
                Formatting.GREEN);
        return 1;
    }

    private static int claim(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
        List<ItemStack> list = CLAIMS.remove(p.getUuid());
        if (list == null || list.isEmpty()) {
            msg(p, "Для вас нет вернувшихся предметов.", Formatting.RED);
            return 0;
        }
        for (ItemStack st : list) p.getInventory().offerOrDrop(st);
        save();
        msg(p, "Получено предметов: " + list.size(), Formatting.GREEN);
        return 1;
    }
}
