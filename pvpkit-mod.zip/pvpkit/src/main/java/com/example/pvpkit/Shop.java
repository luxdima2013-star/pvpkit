package com.example.pvpkit;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Shop {
    public static final String[] CATEGORY_NAMES = {"Всё", "Избранное", "Бой и снаряжение", "Еда", "Блоки", "Редкое"};
    /** Цена за 1 штуку «по умолчанию» для обычных предметов. */
    private static final long BASE_PRICE = 150;
    public static final long RARE_FROM = 10000;

    public record Ench(RegistryKey<Enchantment> key, int level) {}

    /** Создаёт особый предмет (книга с зачарованием, зелье). */
    public interface StackMaker {
        ItemStack make(DynamicRegistryManager reg);
    }

    /** unitPrice — цена за ОДНУ штуку. */
    public record Entry(String id, String name, Item item, long unitPrice, List<Ench> enchants,
                        boolean featured, StackMaker maker) {
        public ItemStack create(DynamicRegistryManager reg, int count) {
            if (maker != null) {
                ItemStack s;
                try {
                    s = maker.make(reg);
                } catch (Exception ex) {
                    s = new ItemStack(item);
                }
                s.setCount(count);
                return s;
            }
            ItemStack stack = new ItemStack(item, count);
            for (Ench e : enchants) {
                stack.addEnchantment(reg.getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(e.key()), e.level());
            }
            return stack;
        }
    }

    private static final List<Entry> FEATURED = new ArrayList<>();
    private static List<Entry> catalog;

    private static Ench e(RegistryKey<Enchantment> key, int level) {
        return new Ench(key, level);
    }

    /** price — цена за весь набор count штук; в каталог кладётся цена за одну штуку. */
    private static void add(String id, String name, Item item, int count, long price, Ench... enchants) {
        long unit = Math.max(1, Math.round(price / (double) count));
        if (unit >= 5000) unit *= 2; // редкое дороже
        FEATURED.add(new Entry(id, name, item, unit, List.of(enchants), true, null));
    }


    private static void addCustom(String id, String name, Item item, long price, StackMaker maker) {
        FEATURED.add(new Entry(id, name, item, price, List.of(), true, maker));
    }

    private static String roman(int n) {
        return switch (n) { case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; default -> "V"; };
    }

    private static void book(String id, String ru, int level, long price) {
        String title = level > 1 || id.equals("fire_aspect") ? ru + " " + roman(level) : ru;
        addCustom("book_" + id, "Книга: " + title, Items.ENCHANTED_BOOK, price, reg -> {
            ItemStack s = new ItemStack(Items.ENCHANTED_BOOK);
            ItemEnchantmentsComponent.Builder b = new ItemEnchantmentsComponent.Builder(ItemEnchantmentsComponent.DEFAULT);
            b.add(reg.getOrThrow(RegistryKeys.ENCHANTMENT)
                    .getOrThrow(RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of("minecraft", id))), level);
            s.set(DataComponentTypes.STORED_ENCHANTMENTS, b.build());
            return s;
        });
    }

    private static void potion(String id, String ru, Item base, String potionId, long price) {
        addCustom(id, ru, base, price, reg -> PotionContentsComponent.createStack(base,
                reg.getOrThrow(RegistryKeys.POTION)
                        .getOrThrow(RegistryKey.of(RegistryKeys.POTION, Identifier.of("minecraft", potionId)))));
    }

    // ---------- каталог ----------

    public static synchronized List<Entry> catalog() {
        if (catalog == null) build();
        return catalog;
    }

    private static final Set<String> EXCLUDED = Set.of(
            "air", "light", "barrier", "bedrock", "command_block", "chain_command_block", "repeating_command_block",
            "command_block_minecart", "debug_stick", "structure_block", "structure_void", "jigsaw", "spawner",
            "trial_spawner", "vault", "end_portal_frame", "reinforced_deepslate", "knowledge_book", "petrified_oak_slab",
            "farmland", "dirt_path", "written_book", "filled_map", "potion", "splash_potion", "lingering_potion",
            "tipped_arrow", "enchanted_book", "suspicious_stew", "ominous_bottle", "player_head", "budding_amethyst",
            "test_block", "test_instance_block", "end_gateway", "end_portal", "nether_portal");

    private static boolean excluded(String path) {
        return EXCLUDED.contains(path) || path.startsWith("infested_")
                || path.contains("command_block") || path.contains("trial_key") || path.contains("test_");
    }

    private static void build() {
        List<Entry> all = new ArrayList<>(FEATURED);
        Set<Item> featuredPlain = new HashSet<>();
        for (Entry f : FEATURED) if (f.enchants().isEmpty() && f.maker() == null) featuredPlain.add(f.item());

        for (Item item : Registries.ITEM) {
            String path = Registries.ITEM.getId(item).getPath();
            if (excluded(path) || featuredPlain.contains(item)) continue;
            long price = autoPrice(path, item);
            if (price > BASE_PRICE) price *= 3; // редкое дороже
            all.add(new Entry(path, path, item, price, List.of(), false, null));
        }
        catalog = normalizePrices(all);
    }

    private static long eggPrice(String p) {
        return switch (p) {
            case "warden_spawn_egg" -> 100000;
            case "elder_guardian_spawn_egg" -> 30000;
            case "ravager_spawn_egg", "evoker_spawn_egg" -> 20000;
            case "ghast_spawn_egg" -> 15000;
            case "breeze_spawn_egg", "piglin_brute_spawn_egg" -> 12000;
            case "enderman_spawn_egg", "creaking_spawn_egg" -> 10000;
            case "blaze_spawn_egg", "witch_spawn_egg", "villager_spawn_egg", "wandering_trader_spawn_egg" -> 8000;
            default -> 4000;
        };
    }

    private static long autoPrice(String p, Item item) {
        if (p.endsWith("_spawn_egg")) return eggPrice(p);
        if (p.endsWith("_nugget") || p.endsWith("_bars") || p.endsWith("chain")) return BASE_PRICE;
        if (p.equals("dragon_egg") || p.equals("dragon_head")) return 100000;
        if (p.equals("netherite_block")) return 200000;
        if (p.equals("netherite_scrap")) return 8000;
        if (p.contains("netherite")) return 60000;
        if (p.equals("diamond_block")) return 27000;
        if (p.contains("diamond_ore")) return 5000;
        if (p.contains("diamond")) return 8000;
        if (p.equals("emerald_block")) return 12000;
        if (p.contains("emerald")) return 1500;
        if (p.equals("gold_block")) return 7000;
        if (p.contains("gold")) return 800;
        if (p.equals("iron_block")) return 4500;
        if (p.contains("iron")) return 500;
        if (p.contains("copper")) return 250;
        if (p.contains("ancient_debris")) return 15000;
        if (p.contains("heart_of_the_sea")) return 20000;
        if (p.contains("trident")) return 30000;
        if (p.contains("shulker")) return 15000;
        if (p.contains("music_disc")) return 5000;
        if (p.contains("smithing_template")) return 8000;
        if (p.contains("pottery_sherd")) return 2000;
        if (p.contains("banner_pattern")) return 3000;
        if (p.contains("skull") || p.endsWith("_head")) return 10000;
        if (p.contains("obsidian")) return 600;
        if (p.contains("lapis")) return 300;
        if (p.contains("redstone")) return 200;
        if (p.contains("quartz")) return 200;
        if (p.contains("amethyst")) return 250;
        if (p.contains("nautilus_shell")) return 5000;
        if (p.contains("sponge")) return 1500;
        if (p.contains("wither_rose")) return 5000;
        // ведра с рыбой, редкие блоки и вещи
        if (p.equals("axolotl_bucket")) return 8000;
        if (p.equals("powder_snow_bucket")) return 1500;
        if (p.equals("milk_bucket")) return 300;
        if (p.endsWith("_bucket") && !p.equals("water_bucket") && !p.equals("lava_bucket")) return 3000;
        if (p.contains("froglight")) return 2000;
        if (p.equals("sniffer_egg")) return 15000;
        if (p.equals("turtle_egg")) return 3000;
        if (p.equals("frogspawn")) return 1500;
        if (p.equals("bee_nest")) return 3000;
        if (p.equals("beehive")) return 400;
        if (p.equals("heavy_core")) return 50000;
        if (p.equals("conduit")) return 20000;
        if (p.equals("recovery_compass")) return 8000;
        if (p.equals("echo_shard")) return 5000;
        if (p.equals("disc_fragment_5")) return 3000;
        if (p.equals("lodestone")) return 5000;
        if (p.equals("crying_obsidian")) return 1500;
        if (p.equals("sculk_catalyst") || p.equals("sculk_shrieker")) return 4000;
        if (p.contains("sculk_sensor")) return 1500;
        if (p.equals("goat_horn")) return 3000;
        if (p.equals("creaking_heart")) return 8000;
        if (p.equals("pitcher_plant") || p.equals("torchflower") || p.contains("eyeblossom")) return 1500;
        if (p.equals("phantom_membrane") || p.equals("ghast_tear") || p.equals("turtle_scute")
                || p.equals("armadillo_scute")) return 1500;
        if (p.equals("turtle_helmet") || p.contains("horse_armor") || p.equals("wolf_armor")) return 3000;
        if (p.equals("spyglass") || p.equals("jukebox")) return 1500;
        if (p.equals("bundle")) return 1000;
        if (p.equals("end_rod") || p.equals("chorus_flower") || p.equals("tnt_minecart")) return 800;
        if (p.equals("brewing_stand")) return 600;
        // остальное — по редкости предмета в самой игре
        Rarity rarity = new ItemStack(item).getRarity();
        if (rarity == Rarity.EPIC) return 20000;
        if (rarity == Rarity.RARE) return 5000;
        if (rarity == Rarity.UNCOMMON) return 1500;
        return BASE_PRICE;
    }

    private static java.util.Map<Item, Long> plain;

    /** Цена покупки одной штуки обычного (не зачарованного) предмета или null. */
    public static synchronized Long plainPrice(Item item) {
        if (plain == null) {
            plain = new java.util.HashMap<>();
            for (Entry e : catalog()) {
                if (e.enchants().isEmpty() && e.maker() == null) plain.putIfAbsent(e.item(), e.unitPrice());
            }
        }
        return plain.get(item);
    }


    // ---------- согласование цен: готовая вещь не может стоить дешевле своих частей ----------

    private static final Map<String, Long> FIXED = Map.ofEntries(
            Map.entry("shulker_shell", 20000L), Map.entry("heavy_core", 40000L), Map.entry("breeze_rod", 3000L),
            Map.entry("mace", 90000L), Map.entry("ancient_debris", 8000L), Map.entry("netherite_scrap", 9000L),
            Map.entry("netherite_ingot", 40000L), Map.entry("redstone", 150L), Map.entry("quartz", 300L),
            Map.entry("copper_ingot", 40L), Map.entry("raw_copper", 35L), Map.entry("raw_iron", 70L),
            Map.entry("raw_gold", 115L), Map.entry("gold_nugget", 15L), Map.entry("iron_nugget", 8L),
            Map.entry("copper_nugget", 5L), Map.entry("dried_ghast", 3000L));

    private static final String[] PIECES = {"sword", "pickaxe", "axe", "shovel", "hoe", "helmet", "chestplate", "leggings", "boots"};
    private static final int[] PIECE_INGOTS = {2, 3, 3, 1, 2, 5, 8, 7, 4};

    private static long gearPrice(int ingots, long unit) {
        return Math.round(ingots * unit * 1.1) + 50;
    }

    private static boolean isPlain(Entry e) {
        return e.enchants().isEmpty() && e.maker() == null;
    }

    private static List<Entry> normalizePrices(List<Entry> list) {
        Map<String, Long> price = new HashMap<>();
        for (Entry e : list) {
            if (isPlain(e)) price.put(Registries.ITEM.getId(e.item()).getPath(), e.unitPrice());
        }
        price.putAll(FIXED);

        // шалкеровы ящики одной цены (2 панциря + сундук), сбруи
        for (String k : new ArrayList<>(price.keySet())) {
            if (k.equals("shulker_box") || k.endsWith("_shulker_box")) price.put(k, 50000L);
            else if (k.endsWith("_harness")) price.put(k, 4000L);
        }

        // блоки руды и ресурсов = N слитков + небольшая наценка
        String[][] blocks = {
                {"iron_block", "iron_ingot", "9"}, {"gold_block", "gold_ingot", "9"}, {"copper_block", "copper_ingot", "9"},
                {"diamond_block", "diamond", "9"}, {"emerald_block", "emerald", "9"}, {"lapis_block", "lapis_lazuli", "9"},
                {"redstone_block", "redstone", "9"}, {"coal_block", "coal", "9"}, {"netherite_block", "netherite_ingot", "9"},
                {"raw_iron_block", "raw_iron", "9"}, {"raw_gold_block", "raw_gold", "9"}, {"raw_copper_block", "raw_copper", "9"},
                {"quartz_block", "quartz", "4"}, {"amethyst_block", "amethyst_shard", "4"}};
        for (String[] b : blocks) {
            Long unit = price.get(b[1]);
            if (unit != null) price.put(b[0], Math.round(Integer.parseInt(b[2]) * unit * 1.05));
        }

        // варианты меди (резная, окисленная, вощёная...) стоят как медный блок
        Long copperBlock = price.get("copper_block");
        if (copperBlock != null) {
            for (String k : new ArrayList<>(price.keySet())) {
                if (k.contains("copper") && price.get(k) == 750L && !k.contains("ore") && !k.contains("ingot")
                        && !k.contains("nugget") && !k.startsWith("raw_")) {
                    price.put(k, copperBlock);
                }
            }
        }

        // инструменты и броня = ингредиенты, у незерита = алмазная вещь + слиток
        String[][] mats = {{"copper", "copper_ingot"}, {"iron", "iron_ingot"}, {"golden", "gold_ingot"}, {"diamond", "diamond"}};
        for (String[] m : mats) {
            Long unit = price.get(m[1]);
            if (unit == null) continue;
            for (int i = 0; i < PIECES.length; i++) {
                String key = m[0] + "_" + PIECES[i];
                if (price.containsKey(key)) price.put(key, gearPrice(PIECE_INGOTS[i], unit));
            }
        }
        Long netherIngot = price.get("netherite_ingot");
        if (netherIngot != null) {
            for (String piece : PIECES) {
                Long dia = price.get("diamond_" + piece);
                String key = "netherite_" + piece;
                if (dia != null && price.containsKey(key)) price.put(key, dia + netherIngot);
            }
        }

        // руда стоит чуть дороже того, что с неё падает
        String[][] ores = {{"iron_ore", "raw_iron"}, {"deepslate_iron_ore", "raw_iron"}, {"gold_ore", "raw_gold"},
                {"deepslate_gold_ore", "raw_gold"}, {"copper_ore", "raw_copper"}, {"deepslate_copper_ore", "raw_copper"},
                {"diamond_ore", "diamond"}, {"deepslate_diamond_ore", "diamond"}, {"emerald_ore", "emerald"},
                {"deepslate_emerald_ore", "emerald"}, {"coal_ore", "coal"}, {"deepslate_coal_ore", "coal"}};
        for (String[] o : ores) {
            Long unit = price.get(o[1]);
            if (unit != null && price.containsKey(o[0])) price.put(o[0], Math.round(unit * 1.15) + 5);
        }

        List<Entry> out = new ArrayList<>(list.size());
        for (Entry e : list) {
            if (isPlain(e)) {
                Long np = price.get(Registries.ITEM.getId(e.item()).getPath());
                if (np != null && np.longValue() != e.unitPrice()) {
                    out.add(new Entry(e.id(), e.name(), e.item(), np, e.enchants(), e.featured(), e.maker()));
                    continue;
                }
            }
            out.add(e);
        }
        return out;
    }

    // ---------- вкладки и поиск ----------

    private static boolean isCombat(String p) {
        return p.endsWith("_sword") || p.endsWith("_axe") || p.endsWith("_pickaxe") || p.endsWith("_shovel")
                || p.endsWith("_hoe") || p.endsWith("_helmet") || p.endsWith("_chestplate") || p.endsWith("_leggings")
                || p.endsWith("_boots") || p.endsWith("_horse_armor") || p.endsWith("arrow")
                || p.equals("bow") || p.equals("crossbow") || p.equals("trident") || p.equals("mace")
                || p.equals("shield") || p.equals("elytra") || p.equals("totem_of_undying")
                || p.equals("ender_pearl") || p.equals("wind_charge") || p.equals("tnt") || p.equals("end_crystal");
    }

    private static boolean matches(Entry e, int category) {
        String path = Registries.ITEM.getId(e.item()).getPath();
        return switch (category) {
            case 0 -> true;
            case 1 -> e.featured();
            case 2 -> isCombat(path);
            case 3 -> new ItemStack(e.item()).contains(DataComponentTypes.FOOD);
            case 4 -> e.item() instanceof BlockItem;
            case 5 -> e.unitPrice() >= RARE_FROM;
            default -> true;
        };
    }

    private static final java.util.Map<String, String> HAY = new java.util.HashMap<>();

    public static synchronized void clearSearchCache() {
        HAY.clear();
    }

    private static synchronized String haystack(Entry e) {
        return HAY.computeIfAbsent(e.id() + "|" + e.enchants().size() + "|" + e.unitPrice(), k -> {
            String path = Registries.ITEM.getId(e.item()).getPath();
            String ru = RuLang.name(path);
            // Если есть настоящее русское название — ищем только по нему (и по английскому id).
            // Встроенный словарь нужен только когда перевод не скачался.
            String base = ru != null ? RuNames.normalize(ru) : RuNames.haystack(path);
            return base + " " + RuNames.normalize(e.id()) + " " + RuNames.normalize(e.name());
        });
    }

    /** Поиск: каждое слово запроса должно встречаться где угодно в названии (регистр не важен, можно часть слова). */
    public static List<Entry> filter(int category, String search) {
        String[] words = null;
        if (search != null && !search.isBlank()) {
            words = RuNames.normalize(search).trim().split("\\s+");
        }
        List<Entry> out = new ArrayList<>();
        for (Entry e : catalog()) {
            if (!matches(e, category)) continue;
            if (words != null) {
                String hay = haystack(e);
                boolean ok = true;
                for (String w : words) {
                    if (!hay.contains(w)) { ok = false; break; }
                }
                if (!ok) continue;
            }
            out.add(e);
        }
        return out;
    }

    static {
        // ---- Еда ----
        add("steak", "Стейк", Items.COOKED_BEEF, 16, 400);
        add("golden_carrot", "Золотая морковь", Items.GOLDEN_CARROT, 16, 500);
        add("golden_apple", "Золотое яблоко", Items.GOLDEN_APPLE, 1, 1500);
        add("ench_golden_apple", "Зачарованное золотое яблоко", Items.ENCHANTED_GOLDEN_APPLE, 1, 25000);

        // ---- Бой ----
        add("ender_pearl", "Жемчуг Края", Items.ENDER_PEARL, 1, 800);
        add("arrows", "Стрелы", Items.ARROW, 32, 600);
        add("bow", "Лук (Сила 3, Прочность 3)", Items.BOW, 1, 3000,
                e(Enchantments.POWER, 3), e(Enchantments.UNBREAKING, 3));
        add("crossbow", "Арбалет (Прочность 3)", Items.CROSSBOW, 1, 2500, e(Enchantments.UNBREAKING, 3));
        add("shield", "Щит", Items.SHIELD, 1, 1200);
        add("tnt", "Динамит", Items.TNT, 8, 4000);
        add("cobweb", "Паутина", Items.COBWEB, 8, 800);
        add("wind_charge", "Заряд ветра", Items.WIND_CHARGE, 16, 2000);
        add("mace", "Булава", Items.MACE, 1, 40000);
        add("totem", "Тотем бессмертия", Items.TOTEM_OF_UNDYING, 1, 20000);
        add("end_crystal", "Кристалл Края", Items.END_CRYSTAL, 1, 6000);

        // ---- Алмазное снаряжение ----
        add("diamond_sword", "Алмазный меч (Острота 3, Прочность 3)", Items.DIAMOND_SWORD, 1, 15000,
                e(Enchantments.SHARPNESS, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_pickaxe", "Алмазная кирка (Эффективность 4, Прочность 3)", Items.DIAMOND_PICKAXE, 1, 15000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_axe", "Алмазный топор (Эффективность 4, Прочность 3)", Items.DIAMOND_AXE, 1, 12000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_shovel", "Алмазная лопата (Эффективность 4, Прочность 3)", Items.DIAMOND_SHOVEL, 1, 8000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_helmet", "Алмазный шлем (Защита 3, Прочность 3)", Items.DIAMOND_HELMET, 1, 12000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_chestplate", "Алмазный нагрудник (Защита 3, Прочность 3)", Items.DIAMOND_CHESTPLATE, 1, 20000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_leggings", "Алмазные поножи (Защита 3, Прочность 3)", Items.DIAMOND_LEGGINGS, 1, 16000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_boots", "Алмазные ботинки (Защита 3, Прочность 3)", Items.DIAMOND_BOOTS, 1, 10000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));

        // ---- Незеритовое снаряжение ----
        add("netherite_sword", "Незеритовый меч (Острота 5, Прочность 3, Починка)", Items.NETHERITE_SWORD, 1, 80000,
                e(Enchantments.SHARPNESS, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_pickaxe", "Незеритовая кирка (Эффективность 5, Прочность 3, Починка)", Items.NETHERITE_PICKAXE, 1, 80000,
                e(Enchantments.EFFICIENCY, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_helmet", "Незеритовый шлем (Защита 4, Прочность 3, Починка)", Items.NETHERITE_HELMET, 1, 70000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_chestplate", "Незеритовый нагрудник (Защита 4, Прочность 3, Починка)", Items.NETHERITE_CHESTPLATE, 1, 120000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_leggings", "Незеритовые поножи (Защита 4, Прочность 3, Починка)", Items.NETHERITE_LEGGINGS, 1, 100000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_boots", "Незеритовые ботинки (Защита 4, Прочность 3, Починка)", Items.NETHERITE_BOOTS, 1, 60000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("elytra", "Элитры", Items.ELYTRA, 1, 100000);
        add("firework", "Фейерверк", Items.FIREWORK_ROCKET, 16, 4000);

        // ---- Ресурсы ----
        add("iron", "Железный слиток", Items.IRON_INGOT, 16, 1200);
        add("gold", "Золотой слиток", Items.GOLD_INGOT, 16, 2000);
        add("diamond", "Алмаз", Items.DIAMOND, 1, 3000);
        add("emerald", "Изумруд", Items.EMERALD, 8, 4000);
        add("netherite_ingot", "Незеритовый слиток", Items.NETHERITE_INGOT, 1, 25000);
        add("ancient_debris", "Древние обломки", Items.ANCIENT_DEBRIS, 1, 15000);
        add("lapis", "Лазурит", Items.LAPIS_LAZULI, 32, 1500);
        add("coal", "Уголь", Items.COAL, 64, 1000);
        add("obsidian", "Обсидиан", Items.OBSIDIAN, 8, 4000);
        add("xp_bottle", "Пузырёк опыта", Items.EXPERIENCE_BOTTLE, 16, 3000);
        add("blaze_rod", "Огненный стержень", Items.BLAZE_ROD, 4, 2500);
        add("ender_eye", "Око Края", Items.ENDER_EYE, 4, 5000);
        add("nether_star", "Звезда Нижнего мира", Items.NETHER_STAR, 1, 60000);

        // ---- Блоки и разное ----
        add("logs", "Дубовые брёвна", Items.OAK_LOG, 64, 800);
        add("cobblestone", "Булыжник", Items.COBBLESTONE, 64, 400);
        add("glass", "Стекло", Items.GLASS, 32, 600);
        add("torch", "Факелы", Items.TORCH, 64, 300);
        add("water_bucket", "Ведро воды", Items.WATER_BUCKET, 1, 500);
        add("lava_bucket", "Ведро лавы", Items.LAVA_BUCKET, 1, 800);
        add("bed", "Кровать", Items.RED_BED, 1, 400);
        add("crafting_table", "Верстак", Items.CRAFTING_TABLE, 1, 200);
        add("furnace", "Печь", Items.FURNACE, 1, 300);
        add("anvil", "Наковальня", Items.ANVIL, 1, 3000);
        add("enchanting_table", "Стол зачарований", Items.ENCHANTING_TABLE, 1, 12000);
        add("ender_chest", "Сундук Края", Items.ENDER_CHEST, 1, 10000);
        add("shulker_box", "Шалкеровый ящик", Items.SHULKER_BOX, 1, 30000);
        add("saddle", "Седло", Items.SADDLE, 1, 5000);
        add("name_tag", "Бирка", Items.NAME_TAG, 1, 3000);
        add("respawn_anchor", "Якорь возрождения", Items.RESPAWN_ANCHOR, 1, 8000);
        add("beacon", "Маяк", Items.BEACON, 1, 150000);

        // ---- Ещё товары ----
        add("trident", "Трезубец (Верность 3, Прочность 3, Громовержец)", Items.TRIDENT, 1, 60000,
                e(Enchantments.LOYALTY, 3), e(Enchantments.UNBREAKING, 3), e(Enchantments.CHANNELING, 1));
        add("fishing_rod", "Удочка (Везучий рыбак 3, Приманка 3, Прочность 3)", Items.FISHING_ROD, 1, 8000,
                e(Enchantments.LUCK_OF_THE_SEA, 3), e(Enchantments.LURE, 3), e(Enchantments.UNBREAKING, 3));
        add("shears", "Ножницы (Эффективность 5, Прочность 3)", Items.SHEARS, 1, 6000,
                e(Enchantments.EFFICIENCY, 5), e(Enchantments.UNBREAKING, 3));
        add("diamond_hoe", "Алмазная мотыга (Эффективность 4, Прочность 3)", Items.DIAMOND_HOE, 1, 8000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("netherite_axe", "Незеритовый топор (Острота 5, Эффективность 5, Прочность 3, Починка)", Items.NETHERITE_AXE, 1, 80000,
                e(Enchantments.SHARPNESS, 5), e(Enchantments.EFFICIENCY, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_shovel", "Незеритовая лопата (Эффективность 5, Прочность 3, Починка)", Items.NETHERITE_SHOVEL, 1, 60000,
                e(Enchantments.EFFICIENCY, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("turtle_helmet", "Шлем-панцирь (Защита 4, Прочность 3)", Items.TURTLE_HELMET, 1, 10000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3));

        // ---- Зачарованные книги ----
        book("mending", "Починка", 1, 40000);
        book("sharpness", "Острота", 5, 15000);
        book("protection", "Защита", 4, 15000);
        book("efficiency", "Эффективность", 5, 12000);
        book("unbreaking", "Прочность", 3, 10000);
        book("fortune", "Удача", 3, 12000);
        book("looting", "Добыча", 3, 12000);
        book("silk_touch", "Шёлковое касание", 1, 15000);
        book("fire_aspect", "Заговор огня", 2, 5000);
        book("power", "Сила", 5, 12000);
        book("infinity", "Бесконечность", 1, 20000);
        book("feather_falling", "Невесомость", 4, 5000);
        book("thorns", "Шипы", 3, 4000);
        book("respiration", "Подводное дыхание", 3, 5000);
        book("depth_strider", "Подводная ходьба", 3, 5000);
        book("swift_sneak", "Проворство", 3, 15000);
        book("sweeping_edge", "Разящий клинок", 3, 8000);
        book("knockback", "Отдача", 2, 4000);
        book("frost_walker", "Ледоход", 2, 6000);
        book("flame", "Заговор огня (лук)", 1, 5000);
        book("multishot", "Тройной выстрел", 1, 5000);
        book("piercing", "Пронзающая стрела", 4, 5000);
        book("quick_charge", "Быстрая перезарядка", 3, 5000);
        book("blast_protection", "Взрывоустойчивость", 4, 8000);
        book("fire_protection", "Огнеупорность", 4, 6000);
        book("projectile_protection", "Защита от снарядов", 4, 6000);
        book("punch", "Огонь (отбрасывание лука)", 2, 4000);
        book("density", "Плотность", 5, 12000);
        book("breach", "Пробивание", 4, 12000);
        book("wind_burst", "Порыв ветра", 3, 12000);

        // ---- Зелья ----
        potion("potion_strength2", "Зелье силы II", Items.POTION, "strong_strength", 3000);
        potion("potion_speed2", "Зелье скорости II", Items.POTION, "strong_swiftness", 1500);
        potion("potion_regen2", "Зелье регенерации II", Items.POTION, "strong_regeneration", 2000);
        potion("potion_heal2", "Зелье исцеления II", Items.POTION, "strong_healing", 800);
        potion("potion_fire_res", "Зелье огнестойкости (длинное)", Items.POTION, "long_fire_resistance", 1500);
        potion("potion_night_vision", "Зелье ночного зрения (длинное)", Items.POTION, "long_night_vision", 600);
        potion("potion_water_breathing", "Зелье подводного дыхания (длинное)", Items.POTION, "long_water_breathing", 600);
        potion("potion_slow_falling", "Зелье медленного падения (длинное)", Items.POTION, "long_slow_falling", 600);
        potion("potion_invisibility", "Зелье невидимости (длинное)", Items.POTION, "long_invisibility", 1500);
        potion("potion_turtle", "Зелье черепашьей мощи II", Items.POTION, "strong_turtle_master", 1500);
        potion("splash_strength2", "Взрывное зелье силы II", Items.SPLASH_POTION, "strong_strength", 4000);
        potion("splash_speed2", "Взрывное зелье скорости II", Items.SPLASH_POTION, "strong_swiftness", 2000);
        potion("splash_regen2", "Взрывное зелье регенерации II", Items.SPLASH_POTION, "strong_regeneration", 2600);
        potion("splash_heal2", "Взрывное зелье исцеления II", Items.SPLASH_POTION, "strong_healing", 1100);
    }

    private Shop() {}
}
