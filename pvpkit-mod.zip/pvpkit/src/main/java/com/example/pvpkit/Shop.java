package com.example.pvpkit;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class Shop {
    public static final String[] CATEGORY_NAMES = {"Всё", "Избранное", "Бой и снаряжение", "Еда", "Блоки", "Редкое"};
    /** Цена за 1 штуку «по умолчанию» для обычных предметов. */
    private static final long BASE_PRICE = 150;
    public static final long RARE_FROM = 10000;

    public record Ench(RegistryKey<Enchantment> key, int level) {}

    /** unitPrice — цена за ОДНУ штуку. */
    public record Entry(String id, String name, Item item, long unitPrice, List<Ench> enchants, boolean featured) {
        public ItemStack create(DynamicRegistryManager reg, int count) {
            ItemStack stack = new ItemStack(item, count);
            for (Ench e : enchants) {
                stack.addEnchantment(reg.getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(e.key()), e.level());
            }
            return stack;
        }
    }

    private static final List<Entry> FEATURED = new ArrayList<>();
    private static List<Entry> catalog;

    private static Ench e(RegistryKey<Enchantment> key, int level) {
        return new Ench(key, level);
    }

    /** price — цена за весь набор count штук; в каталог кладётся цена за одну штуку. */
    private static void add(String id, String name, Item item, int count, long price, Ench... enchants) {
        long unit = Math.max(1, Math.round(price / (double) count));
        if (unit >= 5000) unit *= 2; // редкое дороже
        FEATURED.add(new Entry(id, name, item, unit, List.of(enchants), true));
    }

    // ---------- каталог ----------

    public static synchronized List<Entry> catalog() {
        if (catalog == null) build();
        return catalog;
    }

    private static final Set<String> EXCLUDED = Set.of(
            "air", "light", "barrier", "bedrock", "command_block", "chain_command_block", "repeating_command_block",
            "command_block_minecart", "debug_stick", "structure_block", "structure_void", "jigsaw", "spawner",
            "trial_spawner", "vault", "end_portal_frame", "reinforced_deepslate", "knowledge_book", "petrified_oak_slab",
            "farmland", "dirt_path", "written_book", "filled_map", "potion", "splash_potion", "lingering_potion",
            "tipped_arrow", "enchanted_book", "suspicious_stew", "ominous_bottle", "player_head", "budding_amethyst",
            "test_block", "test_instance_block", "end_gateway", "end_portal", "nether_portal");

    private static boolean excluded(String path) {
        return EXCLUDED.contains(path) || path.contains("spawn_egg") || path.startsWith("infested_")
                || path.contains("command_block") || path.contains("trial_key") || path.contains("test_");
    }

    private static void build() {
        List<Entry> all = new ArrayList<>(FEATURED);
        Set<Item> featuredPlain = new HashSet<>();
        for (Entry f : FEATURED) if (f.enchants().isEmpty()) featuredPlain.add(f.item());

        for (Item item : Registries.ITEM) {
            String path = Registries.ITEM.getId(item).getPath();
            if (excluded(path) || featuredPlain.contains(item)) continue;
            long price = autoPrice(path);
            if (price > BASE_PRICE) price *= 3; // редкое дороже
            all.add(new Entry(path, path, item, price, List.of(), false));
        }
        catalog = all;
    }

    private static long autoPrice(String p) {
        if (p.equals("dragon_egg") || p.equals("dragon_head")) return 100000;
        if (p.equals("netherite_block")) return 200000;
        if (p.equals("netherite_scrap")) return 8000;
        if (p.contains("netherite")) return 60000;
        if (p.equals("diamond_block")) return 27000;
        if (p.contains("diamond_ore")) return 5000;
        if (p.contains("diamond")) return 8000;
        if (p.equals("emerald_block")) return 12000;
        if (p.contains("emerald")) return 1500;
        if (p.equals("gold_block")) return 7000;
        if (p.contains("gold")) return 800;
        if (p.equals("iron_block")) return 4500;
        if (p.contains("iron")) return 500;
        if (p.contains("copper")) return 250;
        if (p.contains("ancient_debris")) return 15000;
        if (p.contains("heart_of_the_sea")) return 20000;
        if (p.contains("trident")) return 30000;
        if (p.contains("shulker")) return 15000;
        if (p.contains("music_disc")) return 5000;
        if (p.contains("smithing_template")) return 8000;
        if (p.contains("pottery_sherd")) return 2000;
        if (p.contains("banner_pattern")) return 3000;
        if (p.contains("skull") || p.endsWith("_head")) return 10000;
        if (p.contains("obsidian")) return 600;
        if (p.contains("lapis")) return 300;
        if (p.contains("redstone")) return 200;
        if (p.contains("quartz")) return 200;
        if (p.contains("amethyst")) return 250;
        if (p.contains("nautilus_shell")) return 5000;
        if (p.contains("sponge")) return 1500;
        if (p.contains("wither_rose")) return 5000;
        return BASE_PRICE;
    }

    // ---------- вкладки и поиск ----------

    private static boolean isCombat(String p) {
        return p.endsWith("_sword") || p.endsWith("_axe") || p.endsWith("_pickaxe") || p.endsWith("_shovel")
                || p.endsWith("_hoe") || p.endsWith("_helmet") || p.endsWith("_chestplate") || p.endsWith("_leggings")
                || p.endsWith("_boots") || p.endsWith("_horse_armor") || p.endsWith("arrow")
                || p.equals("bow") || p.equals("crossbow") || p.equals("trident") || p.equals("mace")
                || p.equals("shield") || p.equals("elytra") || p.equals("totem_of_undying")
                || p.equals("ender_pearl") || p.equals("wind_charge") || p.equals("tnt") || p.equals("end_crystal");
    }

    private static boolean matches(Entry e, int category) {
        String path = Registries.ITEM.getId(e.item()).getPath();
        return switch (category) {
            case 0 -> true;
            case 1 -> e.featured();
            case 2 -> isCombat(path);
            case 3 -> new ItemStack(e.item()).contains(DataComponentTypes.FOOD);
            case 4 -> e.item() instanceof BlockItem;
            case 5 -> e.unitPrice() >= RARE_FROM;
            default -> true;
        };
    }

    private static final java.util.Map<String, String> HAY = new java.util.HashMap<>();

    private static synchronized String haystack(Entry e) {
        return HAY.computeIfAbsent(e.id() + "|" + e.enchants().size() + "|" + e.unitPrice(), k -> {
            String path = Registries.ITEM.getId(e.item()).getPath();
            return RuNames.haystack(path) + " " + RuNames.normalize(e.id()) + " " + RuNames.normalize(e.name());
        });
    }

    /** Поиск: каждое слово запроса должно встречаться где угодно в названии (регистр не важен, можно часть слова). */
    public static List<Entry> filter(int category, String search) {
        String[] words = null;
        if (search != null && !search.isBlank()) {
            words = RuNames.normalize(search).trim().split("\\s+");
        }
        List<Entry> out = new ArrayList<>();
        for (Entry e : catalog()) {
            if (!matches(e, category)) continue;
            if (words != null) {
                String hay = haystack(e);
                boolean ok = true;
                for (String w : words) {
                    if (!hay.contains(w)) { ok = false; break; }
                }
                if (!ok) continue;
            }
            out.add(e);
        }
        return out;
    }

    static {
        // ---- Еда ----
        add("steak", "Стейк", Items.COOKED_BEEF, 16, 400);
        add("golden_carrot", "Золотая морковь", Items.GOLDEN_CARROT, 16, 500);
        add("golden_apple", "Золотое яблоко", Items.GOLDEN_APPLE, 1, 1500);
        add("ench_golden_apple", "Зачарованное золотое яблоко", Items.ENCHANTED_GOLDEN_APPLE, 1, 25000);

        // ---- Бой ----
        add("ender_pearl", "Жемчуг Края", Items.ENDER_PEARL, 1, 800);
        add("arrows", "Стрелы", Items.ARROW, 32, 600);
        add("bow", "Лук (Сила 3, Прочность 3)", Items.BOW, 1, 3000,
                e(Enchantments.POWER, 3), e(Enchantments.UNBREAKING, 3));
        add("crossbow", "Арбалет (Прочность 3)", Items.CROSSBOW, 1, 2500, e(Enchantments.UNBREAKING, 3));
        add("shield", "Щит", Items.SHIELD, 1, 1200);
        add("tnt", "Динамит", Items.TNT, 8, 4000);
        add("cobweb", "Паутина", Items.COBWEB, 8, 800);
        add("wind_charge", "Заряд ветра", Items.WIND_CHARGE, 16, 2000);
        add("mace", "Булава", Items.MACE, 1, 40000);
        add("totem", "Тотем бессмертия", Items.TOTEM_OF_UNDYING, 1, 20000);
        add("end_crystal", "Кристалл Края", Items.END_CRYSTAL, 1, 6000);

        // ---- Алмазное снаряжение ----
        add("diamond_sword", "Алмазный меч (Острота 3, Прочность 3)", Items.DIAMOND_SWORD, 1, 15000,
                e(Enchantments.SHARPNESS, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_pickaxe", "Алмазная кирка (Эффективность 4, Прочность 3)", Items.DIAMOND_PICKAXE, 1, 15000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_axe", "Алмазный топор (Эффективность 4, Прочность 3)", Items.DIAMOND_AXE, 1, 12000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_shovel", "Алмазная лопата (Эффективность 4, Прочность 3)", Items.DIAMOND_SHOVEL, 1, 8000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_helmet", "Алмазный шлем (Защита 3, Прочность 3)", Items.DIAMOND_HELMET, 1, 12000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_chestplate", "Алмазный нагрудник (Защита 3, Прочность 3)", Items.DIAMOND_CHESTPLATE, 1, 20000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_leggings", "Алмазные поножи (Защита 3, Прочность 3)", Items.DIAMOND_LEGGINGS, 1, 16000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_boots", "Алмазные ботинки (Защита 3, Прочность 3)", Items.DIAMOND_BOOTS, 1, 10000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));

        // ---- Незеритовое снаряжение ----
        add("netherite_sword", "Незеритовый меч (Острота 5, Прочность 3, Починка)", Items.NETHERITE_SWORD, 1, 80000,
                e(Enchantments.SHARPNESS, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_pickaxe", "Незеритовая кирка (Эффективность 5, Прочность 3, Починка)", Items.NETHERITE_PICKAXE, 1, 80000,
                e(Enchantments.EFFICIENCY, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_helmet", "Незеритовый шлем (Защита 4, Прочность 3, Починка)", Items.NETHERITE_HELMET, 1, 70000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_chestplate", "Незеритовый нагрудник (Защита 4, Прочность 3, Починка)", Items.NETHERITE_CHESTPLATE, 1, 120000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_leggings", "Незеритовые поножи (Защита 4, Прочность 3, Починка)", Items.NETHERITE_LEGGINGS, 1, 100000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_boots", "Незеритовые ботинки (Защита 4, Прочность 3, Починка)", Items.NETHERITE_BOOTS, 1, 60000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("elytra", "Элитры", Items.ELYTRA, 1, 100000);
        add("firework", "Фейерверк", Items.FIREWORK_ROCKET, 16, 4000);

        // ---- Ресурсы ----
        add("iron", "Железный слиток", Items.IRON_INGOT, 16, 1200);
        add("gold", "Золотой слиток", Items.GOLD_INGOT, 16, 2000);
        add("diamond", "Алмаз", Items.DIAMOND, 1, 3000);
        add("emerald", "Изумруд", Items.EMERALD, 8, 4000);
        add("netherite_ingot", "Незеритовый слиток", Items.NETHERITE_INGOT, 1, 25000);
        add("ancient_debris", "Древние обломки", Items.ANCIENT_DEBRIS, 1, 15000);
        add("lapis", "Лазурит", Items.LAPIS_LAZULI, 32, 1500);
        add("coal", "Уголь", Items.COAL, 64, 1000);
        add("obsidian", "Обсидиан", Items.OBSIDIAN, 8, 4000);
        add("xp_bottle", "Пузырёк опыта", Items.EXPERIENCE_BOTTLE, 16, 3000);
        add("blaze_rod", "Огненный стержень", Items.BLAZE_ROD, 4, 2500);
        add("ender_eye", "Око Края", Items.ENDER_EYE, 4, 5000);
        add("nether_star", "Звезда Нижнего мира", Items.NETHER_STAR, 1, 60000);

        // ---- Блоки и разное ----
        add("logs", "Дубовые брёвна", Items.OAK_LOG, 64, 800);
        add("cobblestone", "Булыжник", Items.COBBLESTONE, 64, 400);
        add("glass", "Стекло", Items.GLASS, 32, 600);
        add("torch", "Факелы", Items.TORCH, 64, 300);
        add("water_bucket", "Ведро воды", Items.WATER_BUCKET, 1, 500);
        add("lava_bucket", "Ведро лавы", Items.LAVA_BUCKET, 1, 800);
        add("bed", "Кровать", Items.RED_BED, 1, 400);
        add("crafting_table", "Верстак", Items.CRAFTING_TABLE, 1, 200);
        add("furnace", "Печь", Items.FURNACE, 1, 300);
        add("anvil", "Наковальня", Items.ANVIL, 1, 3000);
        add("enchanting_table", "Стол зачарований", Items.ENCHANTING_TABLE, 1, 12000);
        add("ender_chest", "Сундук Края", Items.ENDER_CHEST, 1, 10000);
        add("shulker_box", "Шалкеровый ящик", Items.SHULKER_BOX, 1, 30000);
        add("saddle", "Седло", Items.SADDLE, 1, 5000);
        add("name_tag", "Бирка", Items.NAME_TAG, 1, 3000);
        add("respawn_anchor", "Якорь возрождения", Items.RESPAWN_ANCHOR, 1, 8000);
        add("beacon", "Маяк", Items.BEACON, 1, 150000);
    }

    private Shop() {}
}
