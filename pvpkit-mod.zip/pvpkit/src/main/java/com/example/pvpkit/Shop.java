package com.example.pvpkit;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

import java.util.ArrayList;
import java.util.List;

public final class Shop {
    public record Ench(RegistryKey<Enchantment> key, int level) {}

    public record Entry(String id, String name, Item item, int count, long price, List<Ench> enchants) {
        public ItemStack create(DynamicRegistryManager reg) {
            ItemStack stack = new ItemStack(item, count);
            for (Ench e : enchants) {
                stack.addEnchantment(reg.getOrThrow(RegistryKeys.ENCHANTMENT).getOrThrow(e.key()), e.level());
            }
            return stack;
        }
    }

    public static final List<Entry> ITEMS = new ArrayList<>();

    private static Ench e(RegistryKey<Enchantment> key, int level) {
        return new Ench(key, level);
    }

    private static void add(String id, String name, Item item, int count, long price, Ench... enchants) {
        ITEMS.add(new Entry(id, name, item, count, price, List.of(enchants)));
    }

    public static Entry find(String id) {
        for (Entry e : ITEMS) if (e.id().equalsIgnoreCase(id)) return e;
        return null;
    }

    static {
        // ---- Еда ----
        add("steak", "Стейк", Items.COOKED_BEEF, 16, 400);
        add("golden_carrot", "Золотая морковь", Items.GOLDEN_CARROT, 16, 500);
        add("golden_apple", "Золотое яблоко", Items.GOLDEN_APPLE, 1, 1500);
        add("ench_golden_apple", "Зачарованное золотое яблоко", Items.ENCHANTED_GOLDEN_APPLE, 1, 25000);

        // ---- Бой ----
        add("ender_pearl", "Жемчуг Края", Items.ENDER_PEARL, 1, 800);
        add("arrows", "Стрелы", Items.ARROW, 32, 600);
        add("bow", "Лук (Сила 3, Прочность 3)", Items.BOW, 1, 3000,
                e(Enchantments.POWER, 3), e(Enchantments.UNBREAKING, 3));
        add("crossbow", "Арбалет (Прочность 3)", Items.CROSSBOW, 1, 2500, e(Enchantments.UNBREAKING, 3));
        add("shield", "Щит", Items.SHIELD, 1, 1200);
        add("tnt", "Динамит", Items.TNT, 8, 4000);
        add("cobweb", "Паутина", Items.COBWEB, 8, 800);
        add("wind_charge", "Заряд ветра", Items.WIND_CHARGE, 16, 2000);
        add("mace", "Булава", Items.MACE, 1, 40000);
        add("totem", "Тотем бессмертия", Items.TOTEM_OF_UNDYING, 1, 20000);
        add("end_crystal", "Кристалл Края", Items.END_CRYSTAL, 1, 6000);

        // ---- Алмазное снаряжение ----
        add("diamond_sword", "Алмазный меч (Острота 3, Прочность 3)", Items.DIAMOND_SWORD, 1, 15000,
                e(Enchantments.SHARPNESS, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_pickaxe", "Алмазная кирка (Эффективность 4, Прочность 3)", Items.DIAMOND_PICKAXE, 1, 15000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_axe", "Алмазный топор (Эффективность 4, Прочность 3)", Items.DIAMOND_AXE, 1, 12000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_shovel", "Алмазная лопата (Эффективность 4, Прочность 3)", Items.DIAMOND_SHOVEL, 1, 8000,
                e(Enchantments.EFFICIENCY, 4), e(Enchantments.UNBREAKING, 3));
        add("diamond_helmet", "Алмазный шлем (Защита 3, Прочность 3)", Items.DIAMOND_HELMET, 1, 12000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_chestplate", "Алмазный нагрудник (Защита 3, Прочность 3)", Items.DIAMOND_CHESTPLATE, 1, 20000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_leggings", "Алмазные поножи (Защита 3, Прочность 3)", Items.DIAMOND_LEGGINGS, 1, 16000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));
        add("diamond_boots", "Алмазные ботинки (Защита 3, Прочность 3)", Items.DIAMOND_BOOTS, 1, 10000,
                e(Enchantments.PROTECTION, 3), e(Enchantments.UNBREAKING, 3));

        // ---- Незеритовое снаряжение ----
        add("netherite_sword", "Незеритовый меч (Острота 5, Прочность 3, Починка)", Items.NETHERITE_SWORD, 1, 80000,
                e(Enchantments.SHARPNESS, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_pickaxe", "Незеритовая кирка (Эффективность 5, Прочность 3, Починка)", Items.NETHERITE_PICKAXE, 1, 80000,
                e(Enchantments.EFFICIENCY, 5), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_helmet", "Незеритовый шлем (Защита 4, Прочность 3, Починка)", Items.NETHERITE_HELMET, 1, 70000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_chestplate", "Незеритовый нагрудник (Защита 4, Прочность 3, Починка)", Items.NETHERITE_CHESTPLATE, 1, 120000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_leggings", "Незеритовые поножи (Защита 4, Прочность 3, Починка)", Items.NETHERITE_LEGGINGS, 1, 100000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("netherite_boots", "Незеритовые ботинки (Защита 4, Прочность 3, Починка)", Items.NETHERITE_BOOTS, 1, 60000,
                e(Enchantments.PROTECTION, 4), e(Enchantments.UNBREAKING, 3), e(Enchantments.MENDING, 1));
        add("elytra", "Элитры", Items.ELYTRA, 1, 100000);
        add("firework", "Фейерверк", Items.FIREWORK_ROCKET, 16, 4000);

        // ---- Ресурсы ----
        add("iron", "Железный слиток", Items.IRON_INGOT, 16, 1200);
        add("gold", "Золотой слиток", Items.GOLD_INGOT, 16, 2000);
        add("diamond", "Алмаз", Items.DIAMOND, 1, 3000);
        add("emerald", "Изумруд", Items.EMERALD, 8, 4000);
        add("netherite_ingot", "Незеритовый слиток", Items.NETHERITE_INGOT, 1, 25000);
        add("ancient_debris", "Древние обломки", Items.ANCIENT_DEBRIS, 1, 15000);
        add("lapis", "Лазурит", Items.LAPIS_LAZULI, 32, 1500);
        add("coal", "Уголь", Items.COAL, 64, 1000);
        add("obsidian", "Обсидиан", Items.OBSIDIAN, 8, 4000);
        add("xp_bottle", "Пузырёк опыта", Items.EXPERIENCE_BOTTLE, 16, 3000);
        add("blaze_rod", "Огненный стержень", Items.BLAZE_ROD, 4, 2500);
        add("ender_eye", "Око Края", Items.ENDER_EYE, 4, 5000);
        add("nether_star", "Звезда Нижнего мира", Items.NETHER_STAR, 1, 60000);

        // ---- Блоки и разное ----
        add("logs", "Дубовые брёвна", Items.OAK_LOG, 64, 800);
        add("cobblestone", "Булыжник", Items.COBBLESTONE, 64, 400);
        add("glass", "Стекло", Items.GLASS, 32, 600);
        add("torch", "Факелы", Items.TORCH, 64, 300);
        add("water_bucket", "Ведро воды", Items.WATER_BUCKET, 1, 500);
        add("lava_bucket", "Ведро лавы", Items.LAVA_BUCKET, 1, 800);
        add("bed", "Кровать", Items.RED_BED, 1, 400);
        add("crafting_table", "Верстак", Items.CRAFTING_TABLE, 1, 200);
        add("furnace", "Печь", Items.FURNACE, 1, 300);
        add("anvil", "Наковальня", Items.ANVIL, 1, 3000);
        add("enchanting_table", "Стол зачарований", Items.ENCHANTING_TABLE, 1, 12000);
        add("ender_chest", "Сундук Края", Items.ENDER_CHEST, 1, 10000);
        add("shulker_box", "Шалкеровый ящик", Items.SHULKER_BOX, 1, 30000);
        add("saddle", "Седло", Items.SADDLE, 1, 5000);
        add("name_tag", "Бирка", Items.NAME_TAG, 1, 3000);
        add("respawn_anchor", "Якорь возрождения", Items.RESPAWN_ANCHOR, 1, 8000);
        add("beacon", "Маяк", Items.BEACON, 1, 150000);
    }

    private Shop() {}
}
