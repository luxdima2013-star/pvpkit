package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/** /invsee ник — окно с инвентарём игрока. Только просмотр, обновляется каждый тик. */
public class InvseeMenu extends GenericContainerScreenHandler {

    private InvseeMenu(int syncId, PlayerInventory viewerInv, Inventory view) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, viewerInv, view, 6);
    }

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("invsee")
                .then(argument("player", EntityArgumentType.player())
                        .executes(ctx -> {
                            ServerPlayerEntity viewer = ctx.getSource().getPlayerOrThrow();
                            ServerPlayerEntity target = EntityArgumentType.getPlayer(ctx, "player");
                            viewer.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                                    (syncId, playerInv, p) -> new InvseeMenu(syncId, playerInv, new View(target)),
                                    Text.literal("Инвентарь: " + target.getName().getString())));
                            return 1;
                        })));
    }

    // Только просмотр: любые клики игнорируются
    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        setCursorStack(ItemStack.EMPTY);
        sendContentUpdates();
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    /**
     * Окно-«зеркало» инвентаря игрока.
     * Ряды 1-3: основной инвентарь, ряд 4: хотбар, ряд 5: шлем, нагрудник, поножи, ботинки, вторая рука.
     */
    private static final class View implements Inventory {
        private final ServerPlayerEntity target;

        View(ServerPlayerEntity target) {
            this.target = target;
        }

        @Override
        public int size() {
            return 54;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public ItemStack getStack(int slot) {
            if (slot < 27) return target.getInventory().getStack(9 + slot);
            if (slot < 36) return target.getInventory().getStack(slot - 27);
            return switch (slot) {
                case 36 -> target.getEquippedStack(EquipmentSlot.HEAD);
                case 37 -> target.getEquippedStack(EquipmentSlot.CHEST);
                case 38 -> target.getEquippedStack(EquipmentSlot.LEGS);
                case 39 -> target.getEquippedStack(EquipmentSlot.FEET);
                case 40 -> target.getEquippedStack(EquipmentSlot.OFFHAND);
                default -> ItemStack.EMPTY;
            };
        }

        @Override
        public ItemStack removeStack(int slot, int amount) {
            return ItemStack.EMPTY;
        }

        @Override
        public ItemStack removeStack(int slot) {
            return ItemStack.EMPTY;
        }

        @Override
        public void setStack(int slot, ItemStack stack) {
            // только просмотр
        }

        @Override
        public void markDirty() {
        }

        @Override
        public boolean canPlayerUse(PlayerEntity player) {
            return true;
        }

        @Override
        public void clear() {
        }
    }
}
