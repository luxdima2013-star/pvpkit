package com.example.pvpkit;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Меню аукциона: 45 лотов на странице, ЛКМ — купить (свой лот — снять с продажи). */
public class AuctionMenu extends GenericContainerScreenHandler {
    private static final int PAGE_SIZE = 45;
    private static final int PREV = 45;
    private static final int TOGGLE = 49;
    private static final int INFO = 52;
    private static final int NEXT = 53;

    private final SimpleInventory inv;
    private final ServerPlayerEntity viewer;
    private boolean mine = false;
    private int page = 0;
    private List<Auction.Lot> list;

    private AuctionMenu(int syncId, PlayerInventory playerInv, SimpleInventory inv, ServerPlayerEntity viewer) {
        super(ScreenHandlerType.GENERIC_9X6, syncId, playerInv, inv, 6);
        this.inv = inv;
        this.viewer = viewer;
        reload();
        refresh();
    }

    public static void open(ServerPlayerEntity player) {
        player.openHandledScreen(new SimpleNamedScreenHandlerFactory(
                (syncId, playerInv, p) -> new AuctionMenu(syncId, playerInv, new SimpleInventory(54), player),
                Text.literal("Аукцион")));
    }

    // ---------- клики ----------

    @Override
    public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
        if (slotIndex >= 0 && slotIndex < 54
                && (actionType == SlotActionType.PICKUP || actionType == SlotActionType.QUICK_MOVE)) {
            handleClick(slotIndex);
        }
        setCursorStack(ItemStack.EMPTY);
        sendContentUpdates();
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    private void handleClick(int slot) {
        if (slot < PAGE_SIZE) {
            int idx = page * PAGE_SIZE + slot;
            if (idx < list.size()) clickLot(list.get(idx));
        } else if (slot == PREV) {
            if (page > 0) { page--; refresh(); }
        } else if (slot == NEXT) {
            if (page < maxPage()) { page++; refresh(); }
        } else if (slot == TOGGLE) {
            mine = !mine;
            page = 0;
            reload();
            refresh();
        }
    }

    private void clickLot(Auction.Lot lot) {
        if (!Auction.remove(lot)) { // лот уже купили или сняли
            viewer.sendMessage(Text.literal("Этот лот уже недоступен.").formatted(Formatting.RED), true);
            reload();
            refresh();
            return;
        }

        if (lot.seller().equals(viewer.getUuid())) {
            viewer.getInventory().offerOrDrop(lot.stack().copy());
            viewer.sendMessage(Text.literal("Лот снят с продажи, предмет возвращён.").formatted(Formatting.YELLOW), true);
        } else if (!Economy.take(viewer.getUuid(), lot.price())) {
            // не хватило коинов — возвращаем лот на место
            Auction.restore(lot);
            viewer.sendMessage(Text.literal("Не хватает коинов: нужно " + lot.price() + ", у вас "
                    + Economy.balance(viewer.getUuid())).formatted(Formatting.RED), true);
        } else {
            long tax = lot.price() * Auction.TAX_PERCENT / 100;
            Economy.add(lot.seller(), lot.price() - tax);
            viewer.getInventory().offerOrDrop(lot.stack().copy());
            viewer.sendMessage(Text.literal("Куплено за " + lot.price() + " коинов. Баланс: "
                    + Economy.balance(viewer.getUuid())).formatted(Formatting.GREEN), true);
            ServerPlayerEntity seller = Auction.server == null ? null
                    : Auction.server.getPlayerManager().getPlayer(lot.seller());
            if (seller != null) {
                seller.sendMessage(Text.literal("Ваш лот купил " + viewer.getName().getString() + ": +"
                        + (lot.price() - tax) + " коинов (налог " + tax + ")").formatted(Formatting.GOLD), false);
            }
        }
        reload();
        refresh();
    }

    // ---------- отрисовка ----------

    private int maxPage() {
        return Math.max(0, (list.size() - 1) / PAGE_SIZE);
    }

    private void reload() {
        list = Auction.lots(viewer.getUuid(), mine);
    }

    private static Text plain(String s, Formatting color) {
        return Text.literal(s).styled(st -> st.withItalic(false).withColor(color));
    }

    private static ItemStack named(Item item, String name, Formatting color, List<Text> lore) {
        ItemStack s = new ItemStack(item);
        s.set(DataComponentTypes.CUSTOM_NAME, plain(name, color));
        if (!lore.isEmpty()) s.set(DataComponentTypes.LORE, new LoreComponent(lore));
        return s;
    }

    private ItemStack display(Auction.Lot lot) {
        ItemStack s = lot.stack().copy();
        List<Text> lore = new ArrayList<>();
        LoreComponent old = s.get(DataComponentTypes.LORE);
        if (old != null) lore.addAll(old.lines());
        lore.add(plain("Цена: " + lot.price() + " коинов", Formatting.GOLD));
        lore.add(plain("Продавец: " + lot.sellerName(), Formatting.GRAY));
        lore.add(plain("Осталось: " + Cooldowns.format(Math.max(0, lot.expiry() - System.currentTimeMillis())),
                Formatting.GRAY));
        boolean own = lot.seller().equals(viewer.getUuid());
        lore.add(plain(own ? "ЛКМ — снять с продажи" : "ЛКМ — купить", Formatting.YELLOW));
        s.set(DataComponentTypes.LORE, new LoreComponent(lore));
        return s;
    }

    private void refresh() {
        if (page > maxPage()) page = maxPage();
        for (int i = 0; i < PAGE_SIZE; i++) {
            int idx = page * PAGE_SIZE + i;
            inv.setStack(i, idx < list.size() ? display(list.get(idx)) : ItemStack.EMPTY);
        }
        inv.setStack(PREV, page > 0 ? named(Items.ARROW, "← Назад", Formatting.YELLOW, List.of()) : ItemStack.EMPTY);
        inv.setStack(NEXT, page < maxPage() ? named(Items.ARROW, "Вперёд →", Formatting.YELLOW, List.of()) : ItemStack.EMPTY);
        inv.setStack(TOGGLE, named(mine ? Items.ENDER_CHEST : Items.CHEST,
                mine ? "Показаны: мои лоты" : "Показаны: все лоты", Formatting.AQUA,
                List.of(plain("Нажмите, чтобы переключить", Formatting.GRAY))));
        inv.setStack(INFO, named(Items.GOLD_INGOT,
                "Баланс: " + Economy.balance(viewer.getUuid()) + " коинов", Formatting.GOLD,
                List.of(plain("Страница " + (page + 1) + " из " + (maxPage() + 1), Formatting.GRAY),
                        plain("Лотов: " + list.size(), Formatting.GRAY),
                        plain("Выставить: /ah sell <цена> (предмет в руке)", Formatting.GRAY),
                        plain("Комиссия " + Auction.LISTING_FEE_PERCENT + "%, налог " + Auction.TAX_PERCENT + "%",
                                Formatting.GRAY))));
    }
}
