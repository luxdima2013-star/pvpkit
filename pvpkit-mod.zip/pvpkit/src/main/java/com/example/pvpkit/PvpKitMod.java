package com.example.pvpkit;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PvpKitMod implements ModInitializer {
    public static final String MOD_ID = "pvpkit";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        HomeStorage.load();
        Cooldowns.load();
        Economy.init();
        Earnings.init();
        RuLang.loadAsync();
        CombatManager.init();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
        {
            ModCommands.register(dispatcher);
            EconomyCommands.register(dispatcher);
            InvseeMenu.register(dispatcher);
        });
        LOGGER.info("PvP Kit loaded");
    }
}
