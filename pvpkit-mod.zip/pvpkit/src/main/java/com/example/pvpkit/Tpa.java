package com.example.pvpkit;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/**
 * Телепортация к игрокам.
 * /tpa ник — отправить запрос (раз в 30 секунд), заявка живёт 120 секунд;
 * /tpaccept [ник] — принять все запросы (или от одного игрока);
 * /tpacancel [ник] — отклонить все входящие и отменить свои исходящие (или только с одним игроком).
 */
public final class Tpa {
    private static final long EXPIRE_MS = 120_000;
    private static final long SEND_COOLDOWN_MS = 30_000;

    /** Кому -> (от кого -> когда истекает). */
    private static final Map<UUID, Map<UUID, Long>> REQUESTS = new HashMap<>();

    private Tpa() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(literal("tpa")
                .then(argument("player", EntityArgumentType.player()).executes(Tpa::send)));

        d.register(literal("tpaccept")
                .executes(ctx -> accept(ctx, null))
                .then(argument("player", EntityArgumentType.player())
                        .executes(ctx -> accept(ctx, EntityArgumentType.getPlayer(ctx, "player")))));

        d.register(literal("tpacancel")
                .executes(ctx -> cancel(ctx, null))
                .then(argument("player", EntityArgumentType.player())
                        .executes(ctx -> cancel(ctx, EntityArgumentType.getPlayer(ctx, "player")))));
    }

    // ---------- вспомогательное ----------

    private static void msg(ServerPlayerEntity p, String text, Formatting color) {
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    private static String name(ServerPlayerEntity p) {
        return p.getName().getString();
    }

    private static Text button(String symbol, Formatting color, String command, String hover) {
        return Text.literal(symbol).styled(st -> st.withColor(color).withBold(true)
                .withClickEvent(new ClickEvent.RunCommand(command))
                .withHoverEvent(new HoverEvent.ShowText(Text.literal(hover))));
    }

    private static void purge(Map<UUID, Long> map, long now) {
        if (map != null) map.values().removeIf(exp -> exp <= now);
    }

    // ---------- /tpa ----------

    private static int send(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerPlayerEntity from = ctx.getSource().getPlayerOrThrow();
        ServerPlayerEntity to = EntityArgumentType.getPlayer(ctx, "player");
        long now = System.currentTimeMillis();

        if (from.getUuid().equals(to.getUuid())) {
            msg(from, "Нельзя телепортироваться к самому себе.", Formatting.RED);
            return 0;
        }

        // Нельзя повторно кидать тому же игроку, пока старая заявка жива
        Map<UUID, Long> incoming = REQUESTS.computeIfAbsent(to.getUuid(), k -> new LinkedHashMap<>());
        purge(incoming, now);
        Long old = incoming.get(from.getUuid());
        if (old != null) {
            msg(from, "Вы уже отправили запрос игроку " + name(to) + ". Подождите ещё "
                    + Cooldowns.format(old - now) + " или отмените его: /tpacancel", Formatting.RED);
            return 0;
        }

        // Общий кулдаун на отправку: раз в 30 секунд
        long left = Cooldowns.remaining(from.getUuid(), "tpa");
        if (left > 0) {
            msg(from, "Запрос на телепортацию можно отправлять раз в 30 секунд. Подождите ещё "
                    + Cooldowns.format(left), Formatting.RED);
            return 0;
        }
        Cooldowns.set(from.getUuid(), "tpa", SEND_COOLDOWN_MS);
        incoming.put(from.getUuid(), now + EXPIRE_MS);

        msg(from, "Запрос на телепортацию отправлен игроку " + name(to) + ".", Formatting.YELLOW);
        msg(from, "Заявка будет автоматически отменена через 120 секунд. Отменить: /tpacancel", Formatting.GRAY);

        MutableText ask = Text.literal(name(from) + " просит телепортироваться к Вам. ").formatted(Formatting.YELLOW)
                .append(button("[✓]", Formatting.GREEN, "/tpaccept " + name(from), "Принять"))
                .append(Text.literal(" "))
                .append(button("[✗]", Formatting.RED, "/tpacancel " + name(from), "Отклонить"));
        to.sendMessage(ask, false);
        msg(to, "Заявка будет автоматически отменена через 120 секунд", Formatting.GRAY);
        return 1;
    }

    // ---------- /tpaccept ----------

    private static int accept(CommandContext<ServerCommandSource> ctx, ServerPlayerEntity only) throws CommandSyntaxException {
        ServerPlayerEntity me = ctx.getSource().getPlayerOrThrow();
        MinecraftServer server = ctx.getSource().getServer();
        long now = System.currentTimeMillis();

        Map<UUID, Long> incoming = REQUESTS.get(me.getUuid());
        purge(incoming, now);

        List<UUID> senders = new ArrayList<>();
        if (incoming != null) {
            for (UUID id : incoming.keySet()) {
                if (only == null || id.equals(only.getUuid())) senders.add(id);
            }
        }
        if (senders.isEmpty()) {
            msg(me, "У вас нет активных запросов на телепортацию.", Formatting.RED);
            return 0;
        }

        ServerWorld world = Earnings.worldOf(server, me);
        if (world == null) {
            msg(me, "Не удалось определить ваш мир.", Formatting.RED);
            return 0;
        }

        int done = 0;
        for (UUID id : senders) {
            incoming.remove(id);
            ServerPlayerEntity from = server.getPlayerManager().getPlayer(id);
            if (from == null) continue;
            if (CombatManager.isTagged(from)) {
                msg(from, "Вы в PvP режиме, телепортация невозможна.", Formatting.RED);
                msg(me, name(from) + " сейчас в PvP режиме, телепортация отменена.", Formatting.RED);
                continue;
            }
            from.teleport(world, me.getX(), me.getY(), me.getZ(), Set.of(), me.getYaw(), me.getPitch(), true);
            msg(from, "Телепортирование к " + name(me) + ".", Formatting.YELLOW);
            msg(me, name(from) + " телепортирован к Вам.", Formatting.GREEN);
            done++;
        }
        if (done == 0) msg(me, "Телепортироваться некому: игроки не в сети или в PvP режиме.", Formatting.RED);
        return done;
    }

    // ---------- /tpacancel ----------

    private static int cancel(CommandContext<ServerCommandSource> ctx, ServerPlayerEntity only) throws CommandSyntaxException {
        ServerPlayerEntity me = ctx.getSource().getPlayerOrThrow();
        MinecraftServer server = ctx.getSource().getServer();
        long now = System.currentTimeMillis();
        int declined = 0;
        int declinedNamed = 0;
        int cancelled = 0;

        // входящие — отклоняем
        Map<UUID, Long> incoming = REQUESTS.get(me.getUuid());
        purge(incoming, now);
        if (incoming != null) {
            List<UUID> ids = new ArrayList<>(incoming.keySet());
            for (UUID id : ids) {
                if (only != null && !id.equals(only.getUuid())) continue;
                incoming.remove(id);
                declined++;
                ServerPlayerEntity from = server.getPlayerManager().getPlayer(id);
                if (from != null) {
                    msg(from, name(me) + " отклонил ваш запрос на телепортацию.", Formatting.RED);
                    msg(me, "Вы отклонили запрос на телепортацию от " + name(from) + ".", Formatting.RED);
                    declined--; // уже сообщили отдельной строкой
                    declinedNamed++;
                }
            }
        }

        // исходящие — отменяем
        for (Map.Entry<UUID, Map<UUID, Long>> e : REQUESTS.entrySet()) {
            if (only != null && !e.getKey().equals(only.getUuid())) continue;
            purge(e.getValue(), now);
            if (e.getValue().remove(me.getUuid()) != null) {
                cancelled++;
                ServerPlayerEntity to = server.getPlayerManager().getPlayer(e.getKey());
                if (to != null) msg(to, name(me) + " отменил запрос на телепортацию.", Formatting.YELLOW);
            }
        }

        if (declined == 0 && declinedNamed == 0 && cancelled == 0) {
            msg(me, "Нет запросов на телепортацию.", Formatting.RED);
            return 0;
        }
        if (declined > 0) msg(me, "Вы отклонили запросы на телепортацию: " + declined, Formatting.RED);
        if (cancelled > 0) msg(me, "Отменено ваших запросов: " + cancelled, Formatting.YELLOW);
        return declined + declinedNamed + cancelled;
    }
}
