package com.example.pvpkit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Прогресс игроков для наград: серия /daily, максимальный уровень, открытые биомы и измерения. */
public final class Progress {
    public static class Data {
        public long lastDaily;
        public int streak;
        public int maxLevel;
        public Set<String> biomes = new HashSet<>();
        public Set<String> dims = new HashSet<>();
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<Map<String, Data>>() {}.getType();
    private static Map<String, Data> map = new HashMap<>();

    private Progress() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("pvpkit-progress.json");
    }

    public static synchronized void load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Map<String, Data> loaded = GSON.fromJson(Files.readString(f), TYPE);
                if (loaded != null) map = new HashMap<>(loaded);
            }
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось загрузить прогресс", e);
        }
    }

    public static synchronized void save() {
        try {
            Files.writeString(file(), GSON.toJson(map, TYPE));
        } catch (Exception e) {
            PvpKitMod.LOGGER.error("Не удалось сохранить прогресс", e);
        }
    }

    public static synchronized Data get(UUID id) {
        Data d = map.computeIfAbsent(id.toString(), k -> new Data());
        if (d.biomes == null) d.biomes = new HashSet<>();
        if (d.dims == null) d.dims = new HashSet<>();
        return d;
    }
}
